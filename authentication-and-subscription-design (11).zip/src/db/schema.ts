import { relations } from "drizzle-orm";
import {
  boolean,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

export const accountStatusEnum = pgEnum("account_status", [
  "pending_verification",
  "active",
  "suspended",
  "disabled",
  "locked",
  "recovery_required",
]);

export const workspaceTypeEnum = pgEnum("workspace_type", [
  "personal",
  "business",
  "agency",
  "client",
  "project",
  "department",
  "team",
  "enterprise",
]);

export const workspaceStatusEnum = pgEnum("workspace_status", ["active", "suspended", "disabled", "archived"]);

export const userRoleEnum = pgEnum("user_role", [
  "super_owner",
  "platform_admin",
  "admin",
  "organization_owner",
  "agency_owner",
  "agency_admin",
  "manager",
  "team_member",
  "developer",
  "marketer",
  "creator",
  "hr",
  "teacher",
  "student",
  "client",
  "affiliate",
  "viewer",
  "end_user",
]);

export const planTierEnum = pgEnum("plan_tier", [
  "free",
  "starter",
  "professional",
  "business",
  "enterprise",
]);

export const subscriptionStatusEnum = pgEnum("subscription_status", [
  "active",
  "renewal_due",
  "grace_period",
  "limited_access",
  "suspended",
]);

export const invoiceStatusEnum = pgEnum("invoice_status", ["paid", "pending", "failed", "void"]);

export const authProviderCategoryEnum = pgEnum("auth_provider_category", [
  "password",
  "otp",
  "oauth",
  "passkey",
  "biometric",
  "sso",
  "magic_link",
  "recovery",
]);

export const tokenPurposeEnum = pgEnum("token_purpose", [
  "email_verification",
  "password_reset",
  "account_recovery",
  "phone_otp",
  "magic_link",
]);

export const sessionStatusEnum = pgEnum("session_status", ["active", "revoked", "expired", "force_logged_out"]);

export const emailStatusEnum = pgEnum("email_status", ["queued", "sent", "failed", "suppressed"]);

export const moduleCategoryEnum = pgEnum("module_category", [
  "business",
  "agency",
  "crm",
  "marketing",
  "seo",
  "ads",
  "social",
  "ai",
  "automation",
  "analytics",
  "communication",
  "files",
  "knowledge",
  "integration",
  "billing",
  "security",
  "admin",
]);

export const genericStatusEnum = pgEnum("generic_status", ["active", "pending", "paused", "warning", "error", "archived"]);

export const leadStageEnum = pgEnum("lead_stage", [
  "lead",
  "prospect",
  "qualified",
  "proposal",
  "negotiation",
  "won",
  "lost",
  "customer",
  "won_client",
  "onboarding",
  "active_client",
  "paused_client",
  "completed_client",
]);

export const projectStatusEnum = pgEnum("project_status", [
  "not_started",
  "in_progress",
  "review",
  "client_approval",
  "completed",
  "blocked",
  "overdue",
]);

export const taskPriorityEnum = pgEnum("task_priority", ["low", "medium", "high", "urgent"]);

export const connectionStatusEnum = pgEnum("connection_status", [
  "connected",
  "not_connected",
  "authorization_required",
  "error",
]);

export const aiDataSourceEnum = pgEnum("ai_data_source", [
  "ai_generated",
  "verified_external_api",
  "workspace_data",
  "not_connected",
]);

export const auditActorTypeEnum = pgEnum("audit_actor_type", ["user", "system", "ai_assistant"]);

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    displayName: text("display_name").notNull(),
    email: text("email"),
    phone: text("phone"),
    country: text("country").notNull().default("Bangladesh"),
    language: text("language").notNull().default("en"),
    timezone: text("timezone").notNull().default("Asia/Dhaka"),
    accountStatus: accountStatusEnum("account_status").notNull().default("pending_verification"),
    roleLabel: text("role_label").notNull().default("Workspace Owner"),
    emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    firstLoginCompletedAt: timestamp("first_login_completed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    emailIdx: uniqueIndex("users_email_unique_idx").on(table.email),
    phoneIdx: uniqueIndex("users_phone_unique_idx").on(table.phone),
    statusIdx: index("users_account_status_idx").on(table.accountStatus),
  }),
);

export const authCredentials = pgTable(
  "auth_credentials",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    passwordHash: text("password_hash").notNull(),
    passwordAlgo: text("password_algo").notNull().default("scrypt-sha256"),
    passwordUpdatedAt: timestamp("password_updated_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    userIdx: uniqueIndex("auth_credentials_user_unique_idx").on(table.userId),
  }),
);

export const authTokens = pgTable(
  "auth_tokens",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    purpose: tokenPurposeEnum("purpose").notNull(),
    tokenHash: text("token_hash").notNull(),
    destination: text("destination"),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    tokenIdx: uniqueIndex("auth_tokens_hash_unique_idx").on(table.tokenHash),
    userPurposeIdx: index("auth_tokens_user_purpose_idx").on(table.userId, table.purpose),
  }),
);

export const workspaces = pgTable(
  "workspaces",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    ownerUserId: uuid("owner_user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    slug: text("slug").notNull(),
    type: workspaceTypeEnum("type").notNull().default("agency"),
    status: workspaceStatusEnum("status").notNull().default("active"),
    region: text("region").notNull().default("Bangladesh"),
    language: text("language").notNull().default("en"),
    timezone: text("timezone").notNull().default("Asia/Dhaka"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    slugIdx: uniqueIndex("workspaces_slug_unique_idx").on(table.slug),
    ownerIdx: index("workspaces_owner_idx").on(table.ownerUserId),
    statusIdx: index("workspaces_status_idx").on(table.status),
  }),
);

export const workspaceMembers = pgTable(
  "workspace_members",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: userRoleEnum("role").notNull().default("agency_owner"),
    permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
    joinedAt: timestamp("joined_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    membershipIdx: uniqueIndex("workspace_members_unique_idx").on(table.workspaceId, table.userId),
    roleIdx: index("workspace_members_role_idx").on(table.role),
  }),
);

export const rolePermissions = pgTable(
  "role_permissions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    role: userRoleEnum("role").notNull(),
    displayName: text("display_name").notNull(),
    permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
    navigation: jsonb("navigation").$type<string[]>().notNull().default([]),
    isPlatformRole: boolean("is_platform_role").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    roleIdx: uniqueIndex("role_permissions_role_unique_idx").on(table.role),
  }),
);

export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    workspaceId: uuid("workspace_id").references(() => workspaces.id, { onDelete: "set null" }),
    sessionTokenHash: text("session_token_hash").notNull(),
    status: sessionStatusEnum("status").notNull().default("active"),
    ipHash: text("ip_hash"),
    userAgent: text("user_agent"),
    riskScore: integer("risk_score").notNull().default(0),
    suspicious: boolean("suspicious").notNull().default(false),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).defaultNow().notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    tokenIdx: uniqueIndex("sessions_token_unique_idx").on(table.sessionTokenHash),
    userIdx: index("sessions_user_idx").on(table.userId),
    statusIdx: index("sessions_status_idx").on(table.status),
  }),
);

export const trustedDevices = pgTable(
  "trusted_devices",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    deviceHash: text("device_hash").notNull(),
    displayName: text("display_name").notNull(),
    trusted: boolean("trusted").notNull().default(false),
    lastUsedAt: timestamp("last_used_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    deviceIdx: uniqueIndex("trusted_devices_user_hash_unique_idx").on(table.userId, table.deviceHash),
  }),
);

export const emailMessages = pgTable(
  "email_messages",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    workspaceId: uuid("workspace_id").references(() => workspaces.id, { onDelete: "set null" }),
    toEmail: text("to_email").notNull(),
    subject: text("subject").notNull(),
    templateKey: text("template_key").notNull(),
    status: emailStatusEnum("status").notNull().default("queued"),
    metadata: jsonb("metadata").$type<Record<string, string | number | boolean>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    sentAt: timestamp("sent_at", { withTimezone: true }),
  },
  (table) => ({
    userIdx: index("email_messages_user_idx").on(table.userId),
    templateIdx: index("email_messages_template_idx").on(table.templateKey),
  }),
);

export const rateLimitBuckets = pgTable(
  "rate_limit_buckets",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    action: text("action").notNull(),
    identifierHash: text("identifier_hash").notNull(),
    windowStartedAt: timestamp("window_started_at", { withTimezone: true }).defaultNow().notNull(),
    attemptCount: integer("attempt_count").notNull().default(0),
    blockedUntil: timestamp("blocked_until", { withTimezone: true }),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    bucketIdx: uniqueIndex("rate_limit_buckets_action_identifier_unique_idx").on(table.action, table.identifierHash),
  }),
);

export const plans = pgTable(
  "plans",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    tier: planTierEnum("tier").notNull(),
    summary: text("summary").notNull(),
    phase: text("phase").notNull().default("V1"),
    sortOrder: integer("sort_order").notNull().default(0),
    isPublic: boolean("is_public").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    codeIdx: uniqueIndex("plans_code_unique_idx").on(table.code),
  }),
);

export const planEntitlements = pgTable(
  "plan_entitlements",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    planId: uuid("plan_id")
      .notNull()
      .references(() => plans.id, { onDelete: "cascade" }),
    featureKey: text("feature_key").notNull(),
    featureName: text("feature_name").notNull(),
    enabled: boolean("enabled").notNull().default(false),
    limitValue: integer("limit_value"),
    limitUnit: text("limit_unit"),
    enforcement: text("enforcement").notNull().default("backend_required"),
    metadata: jsonb("metadata").$type<Record<string, string | number | boolean>>().notNull().default({}),
  },
  (table) => ({
    entitlementIdx: uniqueIndex("plan_entitlements_unique_idx").on(table.planId, table.featureKey),
    featureIdx: index("plan_entitlements_feature_idx").on(table.featureKey),
  }),
);

export const subscriptions = pgTable(
  "subscriptions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    planId: uuid("plan_id")
      .notNull()
      .references(() => plans.id, { onDelete: "restrict" }),
    status: subscriptionStatusEnum("status").notNull().default("active"),
    renewalState: text("renewal_state").notNull().default("renews automatically"),
    currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }).notNull(),
    paymentProviderRef: text("payment_provider_ref"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    workspaceIdx: uniqueIndex("subscriptions_workspace_unique_idx").on(table.workspaceId),
  }),
);

export const usageMeters = pgTable(
  "usage_meters",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    metricKey: text("metric_key").notNull(),
    metricName: text("metric_name").notNull(),
    used: integer("used").notNull().default(0),
    limitValue: integer("limit_value").notNull().default(0),
    percentUsed: integer("percent_used").notNull().default(0),
    periodLabel: text("period_label").notNull().default("This month"),
    warningThreshold: integer("warning_threshold").notNull().default(80),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    meterIdx: uniqueIndex("usage_meters_unique_idx").on(table.workspaceId, table.metricKey),
  }),
);

export const invoices = pgTable(
  "invoices",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    invoiceNumber: text("invoice_number").notNull(),
    billingMonth: text("billing_month").notNull(),
    status: invoiceStatusEnum("status").notNull().default("pending"),
    providerInvoiceRef: text("provider_invoice_ref"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    invoiceIdx: uniqueIndex("invoices_number_unique_idx").on(table.invoiceNumber),
    workspaceInvoiceIdx: index("invoices_workspace_idx").on(table.workspaceId),
  }),
);

export const authProviderConfigs = pgTable(
  "auth_provider_configs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    providerKey: text("provider_key").notNull(),
    displayName: text("display_name").notNull(),
    category: authProviderCategoryEnum("category").notNull(),
    priority: integer("priority").notNull().default(100),
    enabled: boolean("enabled").notNull().default(false),
    phase: text("phase").notNull().default("V1"),
    enterpriseOnly: boolean("enterprise_only").notNull().default(false),
    metadata: jsonb("metadata").$type<Record<string, string | number | boolean>>().notNull().default({}),
  },
  (table) => ({
    providerIdx: uniqueIndex("auth_provider_configs_key_unique_idx").on(table.providerKey),
  }),
);

export const securitySettings = pgTable(
  "security_settings",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    emailVerified: boolean("email_verified").notNull().default(false),
    phoneVerified: boolean("phone_verified").notNull().default(false),
    passwordReady: boolean("password_ready").notNull().default(false),
    authenticatorEnabled: boolean("authenticator_enabled").notNull().default(false),
    passkeyEnabled: boolean("passkey_enabled").notNull().default(false),
    voiceVerificationReady: boolean("voice_verification_ready").notNull().default(false),
    recoveryCodesReady: boolean("recovery_codes_ready").notNull().default(false),
    trustedDevices: integer("trusted_devices").notNull().default(0),
    securityScore: integer("security_score").notNull().default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    userIdx: uniqueIndex("security_settings_user_unique_idx").on(table.userId),
  }),
);

export const targetUserSegments = pgTable(
  "target_user_segments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    segmentKey: text("segment_key").notNull(),
    label: text("label").notNull(),
    description: text("description").notNull(),
    recommendedModules: jsonb("recommended_modules").$type<string[]>().notNull().default([]),
    recommendedAiAgents: jsonb("recommended_ai_agents").$type<string[]>().notNull().default([]),
    defaultGoals: jsonb("default_goals").$type<string[]>().notNull().default([]),
    sortOrder: integer("sort_order").notNull().default(0),
    enabled: boolean("enabled").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    segmentIdx: uniqueIndex("target_user_segments_key_unique_idx").on(table.segmentKey),
  }),
);

export const userProfiles = pgTable(
  "user_profiles",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    profilePhotoUrl: text("profile_photo_url"),
    professionalTitle: text("professional_title"),
    bio: text("bio"),
    skills: jsonb("skills").$type<string[]>().notNull().default([]),
    experience: jsonb("experience").$type<string[]>().notNull().default([]),
    education: jsonb("education").$type<string[]>().notNull().default([]),
    certifications: jsonb("certifications").$type<string[]>().notNull().default([]),
    portfolio: jsonb("portfolio").$type<string[]>().notNull().default([]),
    website: text("website"),
    socialLinks: jsonb("social_links").$type<Record<string, string>>().notNull().default({}),
    preferences: jsonb("preferences").$type<Record<string, string | number | boolean>>().notNull().default({}),
    privacyControls: jsonb("privacy_controls").$type<Record<string, boolean>>().notNull().default({}),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    profileUserIdx: uniqueIndex("user_profiles_user_unique_idx").on(table.userId),
  }),
);

export const onboardingPreferences = pgTable(
  "onboarding_preferences",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    targetSegmentKey: text("target_segment_key").notNull(),
    whatTheyDo: text("what_they_do").notNull(),
    industry: text("industry").notNull(),
    businessType: text("business_type").notNull(),
    mainGoals: jsonb("main_goals").$type<string[]>().notNull().default([]),
    requiredTools: jsonb("required_tools").$type<string[]>().notNull().default([]),
    preferredLanguage: text("preferred_language").notNull().default("en"),
    preferredTimezone: text("preferred_timezone").notNull().default("Asia/Dhaka"),
    completed: boolean("completed").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    onboardingUserWorkspaceIdx: uniqueIndex("onboarding_preferences_user_workspace_unique_idx").on(table.userId, table.workspaceId),
  }),
);

export const dashboardWidgets = pgTable(
  "dashboard_widgets",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    widgetKey: text("widget_key").notNull(),
    label: text("label").notNull(),
    description: text("description").notNull(),
    requiredPermission: text("required_permission"),
    recommendedForSegments: jsonb("recommended_for_segments").$type<string[]>().notNull().default([]),
    defaultVisible: boolean("default_visible").notNull().default(true),
    customizable: boolean("customizable").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    widgetIdx: uniqueIndex("dashboard_widgets_key_unique_idx").on(table.widgetKey),
  }),
);

export const platformModules = pgTable(
  "platform_modules",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    moduleKey: text("module_key").notNull(),
    name: text("name").notNull(),
    category: moduleCategoryEnum("category").notNull(),
    description: text("description").notNull(),
    enabled: boolean("enabled").notNull().default(true),
    navOrder: integer("nav_order").notNull().default(0),
    requiredPermission: text("required_permission").notNull(),
    entitlementKey: text("entitlement_key"),
    route: text("route").notNull().default("/dashboard"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    moduleIdx: uniqueIndex("platform_modules_key_unique_idx").on(table.moduleKey),
    categoryIdx: index("platform_modules_category_idx").on(table.category),
  }),
);

export const onboardingItems = pgTable(
  "onboarding_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    itemKey: text("item_key").notNull(),
    title: text("title").notNull(),
    description: text("description").notNull(),
    completed: boolean("completed").notNull().default(false),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    itemIdx: uniqueIndex("onboarding_items_workspace_key_unique_idx").on(table.workspaceId, table.itemKey),
  }),
);

export const crmClients = pgTable(
  "crm_clients",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    ownerUserId: uuid("owner_user_id").references(() => users.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    status: genericStatusEnum("status").notNull().default("active"),
    healthScore: integer("health_score").notNull().default(80),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    workspaceClientIdx: index("crm_clients_workspace_idx").on(table.workspaceId),
  }),
);

export const businessOperations = pgTable(
  "business_operations",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    moduleKey: text("module_key").notNull(),
    title: text("title").notNull(),
    status: genericStatusEnum("status").notNull().default("active"),
    progress: integer("progress").notNull().default(0),
    metadata: jsonb("metadata").$type<Record<string, string | number | boolean>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    operationIdx: index("business_operations_workspace_module_idx").on(table.workspaceId, table.moduleKey),
  }),
);

export const integrations = pgTable(
  "integrations",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    providerKey: text("provider_key").notNull(),
    displayName: text("display_name").notNull(),
    status: genericStatusEnum("status").notNull().default("pending"),
    secretsStored: boolean("secrets_stored").notNull().default(false),
    tokenized: boolean("tokenized").notNull().default(true),
    lastSyncAt: timestamp("last_sync_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    integrationIdx: uniqueIndex("integrations_workspace_provider_unique_idx").on(table.workspaceId, table.providerKey),
  }),
);

export const apiKeys = pgTable(
  "api_keys",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    keyPrefix: text("key_prefix").notNull(),
    keyHash: text("key_hash").notNull(),
    active: boolean("active").notNull().default(true),
    lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    apiKeyHashIdx: uniqueIndex("api_keys_hash_unique_idx").on(table.keyHash),
    workspaceApiKeyIdx: index("api_keys_workspace_idx").on(table.workspaceId),
  }),
);

export const businessProfiles = pgTable(
  "business_profiles",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    businessName: text("business_name").notNull(),
    logoUrl: text("logo_url"),
    industry: text("industry").notNull().default("Digital Services"),
    businessType: text("business_type").notNull().default("Agency"),
    website: text("website"),
    location: text("location").notNull().default("Bangladesh"),
    currency: text("currency").notNull().default("BDT"),
    language: text("language").notNull().default("en"),
    taxId: text("tax_id"),
    contactEmail: text("contact_email"),
    contactPhone: text("contact_phone"),
    configuredAgents: jsonb("configured_agents").$type<string[]>().notNull().default([]),
    engineConfig: jsonb("engine_config").$type<Record<string, string | number | boolean>>().notNull().default({}),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    workspaceIdx: uniqueIndex("business_profiles_workspace_unique_idx").on(table.workspaceId),
  }),
);

export const businessCatalogItems = pgTable(
  "business_catalog_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    itemType: text("item_type").notNull(),
    name: text("name").notNull(),
    status: genericStatusEnum("status").notNull().default("active"),
    quantity: integer("quantity").notNull().default(0),
    metadata: jsonb("metadata").$type<Record<string, string | number | boolean>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    workspaceCatalogIdx: index("business_catalog_workspace_type_idx").on(table.workspaceId, table.itemType),
  }),
);

export const crmLeads = pgTable(
  "crm_leads",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    assignedUserId: uuid("assigned_user_id").references(() => users.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    company: text("company"),
    email: text("email"),
    phone: text("phone"),
    source: text("source").notNull().default("Website"),
    stage: leadStageEnum("stage").notNull().default("lead"),
    valueScore: integer("value_score").notNull().default(50),
    nextStep: text("next_step"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    workspaceLeadIdx: index("crm_leads_workspace_stage_idx").on(table.workspaceId, table.stage),
  }),
);

export const projects = pgTable(
  "projects",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    clientId: uuid("client_id").references(() => crmClients.id, { onDelete: "set null" }),
    ownerUserId: uuid("owner_user_id").references(() => users.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    status: projectStatusEnum("status").notNull().default("not_started"),
    priority: taskPriorityEnum("priority").notNull().default("medium"),
    progress: integer("progress").notNull().default(0),
    deadline: timestamp("deadline", { withTimezone: true }),
    viewModes: jsonb("view_modes").$type<string[]>().notNull().default(["kanban", "list", "calendar"]),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    workspaceProjectIdx: index("projects_workspace_status_idx").on(table.workspaceId, table.status),
  }),
);

export const tasks = pgTable(
  "tasks",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    parentTaskId: uuid("parent_task_id"),
    assignedUserId: uuid("assigned_user_id").references(() => users.id, { onDelete: "set null" }),
    title: text("title").notNull(),
    status: projectStatusEnum("status").notNull().default("not_started"),
    priority: taskPriorityEnum("priority").notNull().default("medium"),
    progress: integer("progress").notNull().default(0),
    commentsCount: integer("comments_count").notNull().default(0),
    attachmentsCount: integer("attachments_count").notNull().default(0),
    deadline: timestamp("deadline", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    workspaceTaskIdx: index("tasks_workspace_project_idx").on(table.workspaceId, table.projectId),
  }),
);

export const aiAgents = pgTable(
  "ai_agents",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    agentKey: text("agent_key").notNull(),
    name: text("name").notNull(),
    role: text("role").notNull(),
    enabled: boolean("enabled").notNull().default(true),
    dataPolicy: text("data_policy").notNull().default("AI output must be labeled and verified data must cite an authorized source."),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    agentIdx: uniqueIndex("ai_agents_key_unique_idx").on(table.agentKey),
  }),
);

export const aiOutputs = pgTable(
  "ai_outputs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    agentKey: text("agent_key").notNull(),
    title: text("title").notNull(),
    summary: text("summary").notNull(),
    dataSource: aiDataSourceEnum("data_source").notNull().default("ai_generated"),
    verified: boolean("verified").notNull().default(false),
    externalSourceLabel: text("external_source_label"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    aiOutputWorkspaceIdx: index("ai_outputs_workspace_agent_idx").on(table.workspaceId, table.agentKey),
  }),
);

export const voiceAiConfigs = pgTable(
  "voice_ai_configs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    speechToTextStatus: connectionStatusEnum("speech_to_text_status").notNull().default("authorization_required"),
    textToSpeechStatus: connectionStatusEnum("text_to_speech_status").notNull().default("authorization_required"),
    speakerDetectionStatus: connectionStatusEnum("speaker_detection_status").notNull().default("authorization_required"),
    languageDetectionStatus: connectionStatusEnum("language_detection_status").notNull().default("authorization_required"),
    voiceAssistantStatus: connectionStatusEnum("voice_assistant_status").notNull().default("authorization_required"),
    voiceHistoryEnabled: boolean("voice_history_enabled").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    voiceWorkspaceIdx: uniqueIndex("voice_ai_configs_workspace_unique_idx").on(table.workspaceId),
  }),
);

export const translationConfigs = pgTable(
  "translation_configs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    status: connectionStatusEnum("status").notNull().default("authorization_required"),
    supportedLanguages: jsonb("supported_languages").$type<string[]>().notNull().default(["Bengali", "English", "German", "Chinese", "French", "Spanish"]),
    pipeline: jsonb("pipeline").$type<string[]>().notNull().default(["Speaker", "Speech Recognition", "Language Detection", "Translation", "Text/Voice Output"]),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    translationWorkspaceIdx: uniqueIndex("translation_configs_workspace_unique_idx").on(table.workspaceId),
  }),
);

export const meetingConfigs = pgTable(
  "meeting_configs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    googleAccountStatus: connectionStatusEnum("google_account_status").notNull().default("authorization_required"),
    googleMeetStatus: connectionStatusEnum("google_meet_status").notNull().default("authorization_required"),
    calendarStatus: connectionStatusEnum("calendar_status").notNull().default("authorization_required"),
    liveTranscriptStatus: connectionStatusEnum("live_transcript_status").notNull().default("authorization_required"),
    aiAssistantStatus: connectionStatusEnum("ai_assistant_status").notNull().default("not_connected"),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    meetingWorkspaceIdx: uniqueIndex("meeting_configs_workspace_unique_idx").on(table.workspaceId),
  }),
);

export const osCapabilities = pgTable(
  "os_capabilities",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    systemKey: text("system_key").notNull(),
    name: text("name").notNull(),
    category: text("category").notNull(),
    features: jsonb("features").$type<string[]>().notNull().default([]),
    workflow: jsonb("workflow").$type<string[]>().notNull().default([]),
    status: genericStatusEnum("status").notNull().default("active"),
    externalConnectionRequired: boolean("external_connection_required").notNull().default(false),
    mode: text("mode").notNull().default("workspace_native"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    capabilityIdx: uniqueIndex("os_capabilities_workspace_system_unique_idx").on(table.workspaceId, table.systemKey),
    capabilityCategoryIdx: index("os_capabilities_workspace_category_idx").on(table.workspaceId, table.category),
  }),
);

export const workflowTemplates = pgTable(
  "workflow_templates",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    workflowKey: text("workflow_key").notNull(),
    name: text("name").notNull(),
    steps: jsonb("steps").$type<string[]>().notNull().default([]),
    confirmationRequiredFor: jsonb("confirmation_required_for").$type<string[]>().notNull().default([]),
    enabled: boolean("enabled").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    workflowIdx: uniqueIndex("workflow_templates_workspace_key_unique_idx").on(table.workspaceId, table.workflowKey),
  }),
);

export const aiCommandRuns = pgTable(
  "ai_command_runs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    requestedByUserId: uuid("requested_by_user_id").references(() => users.id, { onDelete: "set null" }),
    commandText: text("command_text").notNull(),
    planSteps: jsonb("plan_steps").$type<string[]>().notNull().default([]),
    requiresConfirmation: boolean("requires_confirmation").notNull().default(true),
    consequentialActions: jsonb("consequential_actions").$type<string[]>().notNull().default([]),
    status: genericStatusEnum("status").notNull().default("pending"),
    outputPolicy: text("output_policy").notNull().default("AI-generated plan only until authorized external actions are confirmed."),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    commandWorkspaceIdx: index("ai_command_runs_workspace_idx").on(table.workspaceId),
  }),
);

export const customAiAgents = pgTable(
  "custom_ai_agents",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    createdByUserId: uuid("created_by_user_id").references(() => users.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    instructions: text("instructions").notNull(),
    knowledgeScopes: jsonb("knowledge_scopes").$type<string[]>().notNull().default([]),
    tools: jsonb("tools").$type<string[]>().notNull().default([]),
    permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
    trigger: text("trigger").notNull().default("manual"),
    workflow: jsonb("workflow").$type<string[]>().notNull().default([]),
    outputFormat: text("output_format").notNull().default("structured_report"),
    approvalRequired: boolean("approval_required").notNull().default(true),
    limits: jsonb("limits").$type<Record<string, string | number | boolean>>().notNull().default({}),
    enabled: boolean("enabled").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    customAgentIdx: uniqueIndex("custom_ai_agents_workspace_name_unique_idx").on(table.workspaceId, table.name),
  }),
);

export const knowledgeDocuments = pgTable(
  "knowledge_documents",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    documentType: text("document_type").notNull(),
    summary: text("summary").notNull(),
    permissionScope: text("permission_scope").notNull().default("workspace.read"),
    authorizedForAi: boolean("authorized_for_ai").notNull().default(true),
    metadata: jsonb("metadata").$type<Record<string, string | number | boolean>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    knowledgeWorkspaceIdx: index("knowledge_documents_workspace_type_idx").on(table.workspaceId, table.documentType),
  }),
);

export const trackingMatrixEvents = pgTable(
  "tracking_matrix_events",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    businessAction: text("business_action").notNull(),
    gtmStatus: connectionStatusEnum("gtm_status").notNull().default("authorization_required"),
    ga4Status: connectionStatusEnum("ga4_status").notNull().default("authorization_required"),
    metaStatus: connectionStatusEnum("meta_status").notNull().default("authorization_required"),
    googleAdsStatus: connectionStatusEnum("google_ads_status").notNull().default("authorization_required"),
    linkedInStatus: connectionStatusEnum("linkedin_status").notNull().default("authorization_required"),
    tikTokStatus: connectionStatusEnum("tiktok_status").notNull().default("authorization_required"),
    healthStatus: genericStatusEnum("health_status").notNull().default("warning"),
    aiDiagnosis: text("ai_diagnosis").notNull().default("Authorization required before testing live tracking."),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    trackingWorkspaceActionIdx: uniqueIndex("tracking_matrix_workspace_action_unique_idx").on(table.workspaceId, table.businessAction),
  }),
);

export const affiliatePrograms = pgTable(
  "affiliate_programs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    programName: text("program_name").notNull(),
    flow: jsonb("flow").$type<string[]>().notNull().default([]),
    fraudDetectionEnabled: boolean("fraud_detection_enabled").notNull().default(true),
    approvalRequired: boolean("approval_required").notNull().default(true),
    status: genericStatusEnum("status").notNull().default("active"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    affiliateProgramIdx: uniqueIndex("affiliate_programs_workspace_name_unique_idx").on(table.workspaceId, table.programName),
  }),
);

export const cpaCampaigns = pgTable(
  "cpa_campaigns",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    campaignName: text("campaign_name").notNull(),
    flow: jsonb("flow").$type<string[]>().notNull().default([]),
    metrics: jsonb("metrics").$type<string[]>().notNull().default([]),
    status: genericStatusEnum("status").notNull().default("active"),
    reportingMode: text("reporting_mode").notNull().default("configured_data_only"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    cpaCampaignIdx: uniqueIndex("cpa_campaigns_workspace_name_unique_idx").on(table.workspaceId, table.campaignName),
  }),
);

export const brandVoiceProfiles = pgTable(
  "brand_voice_profiles",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    brandName: text("brand_name").notNull(),
    tone: text("tone").notNull(),
    audience: text("audience").notNull(),
    language: text("language").notNull().default("en"),
    keywords: jsonb("keywords").$type<string[]>().notNull().default([]),
    cta: text("cta").notNull(),
    style: text("style").notNull(),
    brandRules: jsonb("brand_rules").$type<string[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    brandWorkspaceIdx: uniqueIndex("brand_voice_profiles_workspace_unique_idx").on(table.workspaceId),
  }),
);

export const contentRepurposingPlans = pgTable(
  "content_repurposing_plans",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    sourceType: text("source_type").notNull().default("Blog"),
    sourceTitle: text("source_title").notNull(),
    targetFormats: jsonb("target_formats").$type<string[]>().notNull().default([]),
    approvalRequired: boolean("approval_required").notNull().default(true),
    publishingStatus: connectionStatusEnum("publishing_status").notNull().default("authorization_required"),
    status: genericStatusEnum("status").notNull().default("active"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    repurposeWorkspaceIdx: index("content_repurpose_workspace_idx").on(table.workspaceId),
  }),
);

export const creativeStudioProjects = pgTable(
  "creative_studio_projects",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    studioType: text("studio_type").notNull(),
    title: text("title").notNull(),
    features: jsonb("features").$type<string[]>().notNull().default([]),
    providerStatus: connectionStatusEnum("provider_status").notNull().default("authorization_required"),
    approvalRequired: boolean("approval_required").notNull().default(true),
    status: genericStatusEnum("status").notNull().default("active"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    creativeWorkspaceIdx: index("creative_studio_workspace_type_idx").on(table.workspaceId, table.studioType),
  }),
);

export const dataOperations = pgTable(
  "data_operations",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    operationType: text("operation_type").notNull(),
    title: text("title").notNull(),
    workflow: jsonb("workflow").$type<string[]>().notNull().default([]),
    validationRules: jsonb("validation_rules").$type<string[]>().notNull().default([]),
    validationState: text("validation_state").notNull().default("warning"),
    qualityScore: integer("quality_score").notNull().default(0),
    rollbackFeasible: boolean("rollback_feasible").notNull().default(false),
    status: genericStatusEnum("status").notNull().default("active"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    dataOpsWorkspaceIdx: index("data_operations_workspace_type_idx").on(table.workspaceId, table.operationType),
  }),
);

export const officeAssets = pgTable(
  "office_assets",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    assetType: text("asset_type").notNull(),
    title: text("title").notNull(),
    format: text("format").notNull(),
    features: jsonb("features").$type<string[]>().notNull().default([]),
    compatibilityNote: text("compatibility_note").notNull().default("Supports common DOCX, XLSX, PPTX, PDF and CSV workflows without claiming every proprietary Office feature."),
    version: integer("version").notNull().default(1),
    shared: boolean("shared").notNull().default(false),
    starred: boolean("starred").notNull().default(false),
    status: genericStatusEnum("status").notNull().default("active"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    officeWorkspaceIdx: index("office_assets_workspace_type_idx").on(table.workspaceId, table.assetType),
  }),
);

export const calendarEvents = pgTable(
  "calendar_events",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    eventType: text("event_type").notNull(),
    startAt: timestamp("start_at", { withTimezone: true }).notNull(),
    endAt: timestamp("end_at", { withTimezone: true }).notNull(),
    reminders: jsonb("reminders").$type<string[]>().notNull().default([]),
    participants: jsonb("participants").$type<string[]>().notNull().default([]),
    status: genericStatusEnum("status").notNull().default("active"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    calendarWorkspaceIdx: index("calendar_events_workspace_type_idx").on(table.workspaceId, table.eventType),
  }),
);

export const remoteMeetings = pgTable(
  "remote_meetings",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    providerStatus: connectionStatusEnum("provider_status").notNull().default("authorization_required"),
    liveStatus: text("live_status").notNull().default("not_live"),
    features: jsonb("features").$type<string[]>().notNull().default([]),
    liveIndicators: jsonb("live_indicators").$type<string[]>().notNull().default([]),
    supportedVoicePipeline: jsonb("supported_voice_pipeline").$type<string[]>().notNull().default([]),
    recordingPermitted: boolean("recording_permitted").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    remoteMeetingWorkspaceIdx: index("remote_meetings_workspace_idx").on(table.workspaceId),
  }),
);

export const aiProviderSlots = pgTable(
  "ai_provider_slots",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    providerKey: text("provider_key").notNull(),
    displayName: text("display_name").notNull(),
    providerType: text("provider_type").notNull().default("agent"),
    configuredStatus: text("configured_status").notNull().default("Not Configured"),
    availabilityLabel: text("availability_label").notNull().default("⚪ Not Configured"),
    workloads: jsonb("workloads").$type<string[]>().notNull().default([]),
    capabilityDetection: boolean("capability_detection").notNull().default(true),
    secretPolicy: text("secret_policy").notNull().default("No unrestricted secrets. Provider credentials stay server-side and are never exposed to agents."),
    documentationNote: text("documentation_note"),
    enabled: boolean("enabled").notNull().default(false),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    aiProviderIdx: uniqueIndex("ai_provider_slots_key_unique_idx").on(table.providerKey),
  }),
);

export const modelRoutingRules = pgTable(
  "model_routing_rules",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    taskType: text("task_type").notNull(),
    primaryProviderKey: text("primary_provider_key").notNull(),
    secondaryProviderKey: text("secondary_provider_key"),
    fallbackProviderKey: text("fallback_provider_key"),
    routingReason: text("routing_reason").notNull(),
    costStrategy: text("cost_strategy").notNull().default("balanced"),
    requiresHumanNotificationOnFailure: boolean("requires_human_notification_on_failure").notNull().default(true),
    enabled: boolean("enabled").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    routeRuleIdx: uniqueIndex("model_routing_rules_task_unique_idx").on(table.taskType),
  }),
);

export const agentMarketplaceItems = pgTable(
  "agent_marketplace_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    agentKey: text("agent_key").notNull(),
    name: text("name").notNull(),
    category: text("category").notNull(),
    description: text("description").notNull(),
    permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
    tools: jsonb("tools").$type<string[]>().notNull().default([]),
    requiresApprovalForExternalActions: boolean("requires_approval_for_external_actions").notNull().default(true),
    installedByDefault: boolean("installed_by_default").notNull().default(false),
    enabled: boolean("enabled").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    marketplaceAgentIdx: uniqueIndex("agent_marketplace_items_key_unique_idx").on(table.agentKey),
    marketplaceCategoryIdx: index("agent_marketplace_items_category_idx").on(table.category),
  }),
);

export const agentOrchestrationRuns = pgTable(
  "agent_orchestration_runs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    requestedByUserId: uuid("requested_by_user_id").references(() => users.id, { onDelete: "set null" }),
    userRequest: text("user_request").notNull(),
    moderatorPlan: jsonb("moderator_plan").$type<string[]>().notNull().default([]),
    selectedAgents: jsonb("selected_agents").$type<string[]>().notNull().default([]),
    tools: jsonb("tools").$type<string[]>().notNull().default([]),
    progressStatus: text("progress_status").notNull().default("planned"),
    failurePolicy: text("failure_policy").notNull().default("Retry, fallback, then human notification. Never silently fabricate results."),
    finalOutputType: text("final_output_type").notNull().default("professional_report"),
    approvalRequired: boolean("approval_required").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    orchestrationWorkspaceIdx: index("agent_orchestration_workspace_idx").on(table.workspaceId),
  }),
);

export const leadCompanies = pgTable(
  "lead_companies",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    website: text("website"),
    industry: text("industry"),
    location: text("location"),
    socialProfiles: jsonb("social_profiles").$type<Record<string, string>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    companyUniqueIdx: uniqueIndex("lead_companies_workspace_name_unique_idx").on(table.workspaceId, table.name),
    companyWorkspaceIdx: index("lead_companies_workspace_idx").on(table.workspaceId),
  }),
);

export const leadContacts = pgTable(
  "lead_contacts",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    companyId: uuid("company_id").references(() => leadCompanies.id, { onDelete: "cascade" }),
    name: text("name"),
    email: text("email"),
    phone: text("phone"),
    whatsapp: text("whatsapp"),
    role: text("role"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    contactWorkspaceIdx: index("lead_contacts_workspace_idx").on(table.workspaceId),
    contactEmailIdx: index("lead_contacts_email_idx").on(table.email),
  }),
);

export const leadRecords = pgTable(
  "lead_records",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    companyId: uuid("company_id").references(() => leadCompanies.id, { onDelete: "set null" }),
    contactId: uuid("contact_id").references(() => leadContacts.id, { onDelete: "set null" }),
    leadCode: text("lead_code").notNull(),
    company: text("company").notNull(),
    contact: text("contact"),
    email: text("email"),
    phone: text("phone"),
    whatsapp: text("whatsapp"),
    website: text("website"),
    industry: text("industry"),
    location: text("location"),
    socialProfiles: jsonb("social_profiles").$type<Record<string, string>>().notNull().default({}),
    leadSource: text("lead_source").notNull().default("Manual"),
    leadScore: integer("lead_score").notNull().default(0),
    websiteScore: integer("website_score").notNull().default(0),
    seoScore: integer("seo_score").notNull().default(0),
    localSeoScore: integer("local_seo_score").notNull().default(0),
    socialScore: integer("social_score").notNull().default(0),
    recommendedServices: jsonb("recommended_services").$type<string[]>().notNull().default([]),
    status: text("status").notNull().default("New Lead"),
    assignedUserId: uuid("assigned_user_id").references(() => users.id, { onDelete: "set null" }),
    tags: jsonb("tags").$type<string[]>().notNull().default([]),
    aiSummary: text("ai_summary"),
    aiScoreReasoning: jsonb("ai_score_reasoning").$type<string[]>().notNull().default([]),
    lastContactAt: timestamp("last_contact_at", { withTimezone: true }),
    nextFollowUpAt: timestamp("next_follow_up_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    leadCodeIdx: uniqueIndex("lead_records_workspace_code_unique_idx").on(table.workspaceId, table.leadCode),
    leadWorkspaceStatusIdx: index("lead_records_workspace_status_idx").on(table.workspaceId, table.status),
    leadWorkspaceScoreIdx: index("lead_records_workspace_score_idx").on(table.workspaceId, table.leadScore),
    leadEmailIdx: index("lead_records_email_idx").on(table.email),
    leadWebsiteIdx: index("lead_records_website_idx").on(table.website),
  }),
);

export const leadPipelineStages = pgTable(
  "lead_pipeline_stages",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
    color: text("color").notNull().default("purple"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    pipelineStageIdx: uniqueIndex("lead_pipeline_stage_workspace_name_unique_idx").on(table.workspaceId, table.name),
  }),
);

export const websiteAudits = pgTable(
  "website_audits",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    leadId: uuid("lead_id").references(() => leadRecords.id, { onDelete: "cascade" }),
    url: text("url").notNull(),
    status: text("status").notNull().default("completed"),
    httpStatus: integer("http_status"),
    title: text("title"),
    metaDescription: text("meta_description"),
    h1Count: integer("h1_count").notNull().default(0),
    imageCount: integer("image_count").notNull().default(0),
    imagesMissingAlt: integer("images_missing_alt").notNull().default(0),
    internalLinkCount: integer("internal_link_count").notNull().default(0),
    externalLinkCount: integer("external_link_count").notNull().default(0),
    hasHttps: boolean("has_https").notNull().default(false),
    hasRobotsTxt: boolean("has_robots_txt").notNull().default(false),
    hasSitemap: boolean("has_sitemap").notNull().default(false),
    hasCanonical: boolean("has_canonical").notNull().default(false),
    hasSchema: boolean("has_schema").notNull().default(false),
    hasViewport: boolean("has_viewport").notNull().default(false),
    hasCta: boolean("has_cta").notNull().default(false),
    hasContactInfo: boolean("has_contact_info").notNull().default(false),
    websiteScore: integer("website_score").notNull().default(0),
    seoScore: integer("seo_score").notNull().default(0),
    conversionScore: integer("conversion_score").notNull().default(0),
    performanceScore: integer("performance_score").notNull().default(0),
    summary: text("summary"),
    errorMessage: text("error_message"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    websiteAuditWorkspaceIdx: index("website_audits_workspace_idx").on(table.workspaceId),
    websiteAuditLeadIdx: index("website_audits_lead_idx").on(table.leadId),
  }),
);

export const auditFindings = pgTable(
  "audit_findings",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    auditId: uuid("audit_id").notNull().references(() => websiteAudits.id, { onDelete: "cascade" }),
    category: text("category").notNull(),
    problem: text("problem").notNull(),
    evidence: text("evidence").notNull(),
    severity: text("severity").notNull().default("medium"),
    businessImpact: text("business_impact").notNull(),
    recommendedService: text("recommended_service").notNull(),
    recommendedAction: text("recommended_action").notNull(),
    confidenceLevel: integer("confidence_level").notNull().default(70),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    findingAuditIdx: index("audit_findings_audit_idx").on(table.auditId),
    findingWorkspaceIdx: index("audit_findings_workspace_idx").on(table.workspaceId),
  }),
);

export const leadOpportunities = pgTable(
  "lead_opportunities",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    leadId: uuid("lead_id").notNull().references(() => leadRecords.id, { onDelete: "cascade" }),
    problem: text("problem").notNull(),
    evidence: text("evidence").notNull(),
    severity: text("severity").notNull(),
    businessImpact: text("business_impact").notNull(),
    recommendedService: text("recommended_service").notNull(),
    recommendedAction: text("recommended_action").notNull(),
    confidenceLevel: integer("confidence_level").notNull().default(70),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    opportunityLeadIdx: index("lead_opportunities_lead_idx").on(table.leadId),
    opportunityWorkspaceIdx: index("lead_opportunities_workspace_idx").on(table.workspaceId),
  }),
);

export const outreachMessages = pgTable(
  "outreach_messages",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    leadId: uuid("lead_id").notNull().references(() => leadRecords.id, { onDelete: "cascade" }),
    channel: text("channel").notNull(),
    subject: text("subject"),
    body: text("body").notNull(),
    followUpBody: text("follow_up_body"),
    status: text("status").notNull().default("AI Generated"),
    providerStatus: text("provider_status").notNull().default("Integration Required"),
    scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
    sentAt: timestamp("sent_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    outreachLeadIdx: index("outreach_messages_lead_idx").on(table.leadId),
    outreachWorkspaceIdx: index("outreach_messages_workspace_idx").on(table.workspaceId),
  }),
);

export const leadActivities = pgTable(
  "lead_activities",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    leadId: uuid("lead_id").references(() => leadRecords.id, { onDelete: "cascade" }),
    activityType: text("activity_type").notNull(),
    description: text("description").notNull(),
    metadata: jsonb("metadata").$type<Record<string, string | number | boolean>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    activityLeadIdx: index("lead_activities_lead_idx").on(table.leadId),
    activityWorkspaceIdx: index("lead_activities_workspace_idx").on(table.workspaceId),
  }),
);

export const leadNotes = pgTable(
  "lead_notes",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    leadId: uuid("lead_id").notNull().references(() => leadRecords.id, { onDelete: "cascade" }),
    note: text("note").notNull(),
    createdByUserId: uuid("created_by_user_id").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    noteLeadIdx: index("lead_notes_lead_idx").on(table.leadId),
  }),
);

export const salesDeals = pgTable(
  "sales_deals",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    leadId: uuid("lead_id").references(() => leadRecords.id, { onDelete: "set null" }),
    title: text("title").notNull(),
    stage: text("stage").notNull().default("New Lead"),
    dealValue: integer("deal_value").notNull().default(0),
    expectedCloseDate: timestamp("expected_close_date", { withTimezone: true }),
    status: text("status").notNull().default("open"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    dealWorkspaceStageIdx: index("sales_deals_workspace_stage_idx").on(table.workspaceId, table.stage),
  }),
);

export const outreachCampaigns = pgTable(
  "outreach_campaigns",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    channel: text("channel").notNull().default("email"),
    status: text("status").notNull().default("Draft"),
    dailyLimit: integer("daily_limit").notNull().default(25),
    complianceNotes: jsonb("compliance_notes").$type<string[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    campaignWorkspaceIdx: index("outreach_campaigns_workspace_idx").on(table.workspaceId),
  }),
);

export const campaignSteps = pgTable(
  "campaign_steps",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    campaignId: uuid("campaign_id").notNull().references(() => outreachCampaigns.id, { onDelete: "cascade" }),
    dayOffset: integer("day_offset").notNull().default(1),
    title: text("title").notNull(),
    instruction: text("instruction").notNull(),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    campaignStepIdx: index("campaign_steps_campaign_idx").on(table.campaignId),
  }),
);

export const automationWorkflows = pgTable(
  "automation_workflows",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    trigger: text("trigger").notNull(),
    steps: jsonb("steps").$type<string[]>().notNull().default([]),
    requiresApproval: boolean("requires_approval").notNull().default(true),
    status: text("status").notNull().default("Draft"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    automationWorkflowIdx: uniqueIndex("automation_workflows_workspace_name_unique_idx").on(table.workspaceId, table.name),
  }),
);

export const leadFiles = pgTable(
  "lead_files",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    leadId: uuid("lead_id").references(() => leadRecords.id, { onDelete: "set null" }),
    fileName: text("file_name").notNull(),
    fileType: text("file_type").notNull(),
    fileSize: integer("file_size").notNull().default(0),
    uploadedByUserId: uuid("uploaded_by_user_id").references(() => users.id, { onDelete: "set null" }),
    processingStatus: text("processing_status").notNull().default("Uploaded"),
    aiAnalysisStatus: text("ai_analysis_status").notNull().default("Integration Required"),
    extractedInformation: jsonb("extracted_information").$type<Record<string, string | number | boolean>>().notNull().default({}),
    errors: jsonb("errors").$type<string[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    leadFilesWorkspaceIdx: index("lead_files_workspace_idx").on(table.workspaceId),
    leadFilesLeadIdx: index("lead_files_lead_idx").on(table.leadId),
  }),
);

export const aiProcessingJobs = pgTable(
  "ai_processing_jobs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    leadId: uuid("lead_id").references(() => leadRecords.id, { onDelete: "set null" }),
    jobType: text("job_type").notNull(),
    status: text("status").notNull().default("Queued"),
    progress: integer("progress").notNull().default(0),
    resultSummary: text("result_summary"),
    errorMessage: text("error_message"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    aiJobsWorkspaceIdx: index("ai_processing_jobs_workspace_status_idx").on(table.workspaceId, table.status),
  }),
);

export const leadNotifications = pgTable(
  "lead_notifications",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
    type: text("type").notNull(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    read: boolean("read").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    notificationWorkspaceIdx: index("lead_notifications_workspace_idx").on(table.workspaceId),
  }),
);

export const leadPlatformIntegrations = pgTable(
  "lead_platform_integrations",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    providerKey: text("provider_key").notNull(),
    displayName: text("display_name").notNull(),
    category: text("category").notNull(),
    status: text("status").notNull().default("Disconnected"),
    lastTestStatus: text("last_test_status").notNull().default("Not Tested"),
    setupInstructions: text("setup_instructions").notNull(),
    requiresSecret: boolean("requires_secret").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    leadIntegrationIdx: uniqueIndex("lead_platform_integrations_workspace_provider_unique_idx").on(table.workspaceId, table.providerKey),
  }),
);

export const leadReports = pgTable(
  "lead_reports",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    leadId: uuid("lead_id").references(() => leadRecords.id, { onDelete: "set null" }),
    reportType: text("report_type").notNull(),
    title: text("title").notNull(),
    summary: text("summary").notNull(),
    dataSource: text("data_source").notNull().default("workspace_data"),
    status: text("status").notNull().default("Ready"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    leadReportsWorkspaceIdx: index("lead_reports_workspace_idx").on(table.workspaceId),
  }),
);

export const suppressionEntries = pgTable(
  "suppression_entries",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    channel: text("channel").notNull(),
    destination: text("destination").notNull(),
    reason: text("reason").notNull().default("unsubscribe"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    suppressionUniqueIdx: uniqueIndex("suppression_entries_workspace_destination_unique_idx").on(table.workspaceId, table.destination),
  }),
);

export const jarvisCommandCenterRuns = pgTable(
  "jarvis_command_center_runs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    requestedByUserId: uuid("requested_by_user_id").references(() => users.id, { onDelete: "set null" }),
    commandText: text("command_text").notNull(),
    mode: text("mode").notNull().default("hybrid"),
    checkedSystems: jsonb("checked_systems").$type<string[]>().notNull().default([]),
    priorityActions: jsonb("priority_actions").$type<string[]>().notNull().default([]),
    approvalRequiredActions: jsonb("approval_required_actions").$type<string[]>().notNull().default([]),
    resultSummary: text("result_summary").notNull(),
    status: text("status").notNull().default("Completed"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    jarvisRunWorkspaceIdx: index("jarvis_runs_workspace_idx").on(table.workspaceId),
  }),
);

export const n8nBackboneWorkflows = pgTable(
  "n8n_backbone_workflows",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    workflowKey: text("workflow_key").notNull(),
    name: text("name").notNull(),
    trigger: text("trigger").notNull(),
    steps: jsonb("steps").$type<string[]>().notNull().default([]),
    status: text("status").notNull().default("Integration Required"),
    n8nWebhookConfigured: boolean("n8n_webhook_configured").notNull().default(false),
    lastRunStatus: text("last_run_status").notNull().default("NO DATA"),
    setupInstructions: text("setup_instructions").notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    n8nWorkflowIdx: uniqueIndex("n8n_workflows_workspace_key_unique_idx").on(table.workspaceId, table.workflowKey),
  }),
);

export const meetingIntelligenceSessions = pgTable(
  "meeting_intelligence_sessions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    platform: text("platform").notNull().default("Google Meet / Teams / Zoom / Supported Platform"),
    yourLanguage: text("your_language").notNull().default("Bangla"),
    clientLanguage: text("client_language").notNull().default("Japanese"),
    mode: text("mode").notNull().default("Full Hybrid"),
    providerStatus: text("provider_status").notNull().default("Integration Required"),
    liveStatus: text("live_status").notNull().default("Not Live"),
    capturedSignals: jsonb("captured_signals").$type<string[]>().notNull().default([]),
    suggestedAnswers: jsonb("suggested_answers").$type<string[]>().notNull().default([]),
    transcriptStatus: text("transcript_status").notNull().default("AUTHORIZATION REQUIRED"),
    translationStatus: text("translation_status").notNull().default("AUTHORIZATION REQUIRED"),
    voiceOutputStatus: text("voice_output_status").notNull().default("AUTHORIZATION REQUIRED"),
    autonomousReplyEnabled: boolean("autonomous_reply_enabled").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    meetingIntelWorkspaceIdx: index("meeting_intelligence_workspace_idx").on(table.workspaceId),
  }),
);

export const businessProducts = pgTable(
  "business_products",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    sku: text("sku").notNull(),
    price: integer("price").notNull().default(0),
    cost: integer("cost").notNull().default(0),
    stock: integer("stock").notNull().default(0),
    supplier: text("supplier"),
    category: text("category"),
    imageUrl: text("image_url"),
    description: text("description"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    productSkuIdx: uniqueIndex("business_products_workspace_sku_unique_idx").on(table.workspaceId, table.sku),
  }),
);

export const businessFinanceEntries = pgTable(
  "business_finance_entries",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    entryType: text("entry_type").notNull(),
    label: text("label").notNull(),
    amount: integer("amount").notNull().default(0),
    period: text("period").notNull().default("This Month"),
    source: text("source").notNull().default("Manual"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    financeWorkspaceIdx: index("business_finance_workspace_type_idx").on(table.workspaceId, table.entryType),
  }),
);

export const backlinkWorkLogs = pgTable(
  "backlink_work_logs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    memberUserId: uuid("member_user_id").references(() => users.id, { onDelete: "set null" }),
    fileName: text("file_name").notNull(),
    submittedLinks: integer("submitted_links").notNull().default(0),
    approvedLinks: integer("approved_links").notNull().default(0),
    rejectedLinks: integer("rejected_links").notNull().default(0),
    ratePerLink: integer("rate_per_link").notNull().default(10),
    earningAmount: integer("earning_amount").notNull().default(0),
    validationStatus: text("validation_status").notNull().default("Pending Approval"),
    paymentStatus: text("payment_status").notNull().default("Pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    backlinkWorkspaceIdx: index("backlink_work_workspace_idx").on(table.workspaceId),
  }),
);

export const serverJarvisSnapshots = pgTable(
  "server_jarvis_snapshots",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").references(() => workspaces.id, { onDelete: "cascade" }),
    apiStatus: text("api_status").notNull(),
    databaseStatus: text("database_status").notNull(),
    memoryUsedMb: integer("memory_used_mb").notNull().default(0),
    uptimeSeconds: integer("uptime_seconds").notNull().default(0),
    failedWorkflows: integer("failed_workflows").notNull().default(0),
    queueStatus: text("queue_status").notNull().default("NO DATA"),
    recoveryPolicy: text("recovery_policy").notNull().default("Detect → Diagnose → Safe Recovery → Health Check → Human Alert if needed. No destructive unrestricted actions."),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    serverSnapshotWorkspaceIdx: index("server_jarvis_workspace_idx").on(table.workspaceId),
  }),
);

export const aiBackupPolicies = pgTable(
  "ai_backup_policies",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    policyKey: text("policy_key").notNull(),
    name: text("name").notNull(),
    layers: jsonb("layers").$type<string[]>().notNull().default([]),
    consensusMode: boolean("consensus_mode").notNull().default(true),
    humanHandoffRequired: boolean("human_handoff_required").notNull().default(true),
    noFabricationPolicy: text("no_fabrication_policy").notNull().default("If AI/provider is unavailable, show failure, retry option, backup option, or human assistance. Never fake success."),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    aiBackupPolicyIdx: uniqueIndex("ai_backup_policies_key_unique_idx").on(table.policyKey),
  }),
);

export const aiWorkforceEmployees = pgTable(
  "ai_workforce_employees",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    employeeKey: text("employee_key").notNull(),
    name: text("name").notNull(),
    department: text("department").notNull(),
    level: integer("level").notNull().default(4),
    role: text("role").notNull(),
    skills: jsonb("skills").$type<string[]>().notNull().default([]),
    modelPolicy: text("model_policy").notNull().default("route_via_nova_model_router"),
    tools: jsonb("tools").$type<string[]>().notNull().default([]),
    permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
    memoryScopes: jsonb("memory_scopes").$type<string[]>().notNull().default([]),
    instructions: text("instructions").notNull(),
    status: text("status").notNull().default("Idle"),
    managerEmployeeKey: text("manager_employee_key"),
    escalationRules: jsonb("escalation_rules").$type<string[]>().notNull().default([]),
    performanceScore: integer("performance_score").notNull().default(0),
    successRate: integer("success_rate").notNull().default(0),
    tasksCompleted: integer("tasks_completed").notNull().default(0),
    tasksFailed: integer("tasks_failed").notNull().default(0),
    usageUnits: integer("usage_units").notNull().default(0),
    estimatedCostCents: integer("estimated_cost_cents").notNull().default(0),
    enabled: boolean("enabled").notNull().default(true),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    aiEmployeeUniqueIdx: uniqueIndex("ai_workforce_workspace_employee_unique_idx").on(table.workspaceId, table.employeeKey),
    aiEmployeeDepartmentIdx: index("ai_workforce_workspace_department_idx").on(table.workspaceId, table.department),
    aiEmployeeStatusIdx: index("ai_workforce_workspace_status_idx").on(table.workspaceId, table.status),
  }),
);

export const aiWorkforceTasks = pgTable(
  "ai_workforce_tasks",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    requestedByUserId: uuid("requested_by_user_id").references(() => users.id, { onDelete: "set null" }),
    assignedEmployeeId: uuid("assigned_employee_id").references(() => aiWorkforceEmployees.id, { onDelete: "set null" }),
    taskCode: text("task_code").notNull(),
    objective: text("objective").notNull(),
    inputs: jsonb("inputs").$type<Record<string, string | number | boolean>>().notNull().default({}),
    tools: jsonb("tools").$type<string[]>().notNull().default([]),
    status: text("status").notNull().default("Queued"),
    result: text("result"),
    verification: text("verification"),
    approvalStatus: text("approval_status").notNull().default("Not Required"),
    usageUnits: integer("usage_units").notNull().default(0),
    estimatedCostCents: integer("estimated_cost_cents").notNull().default(0),
    errorHistory: jsonb("error_history").$type<string[]>().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    aiTaskCodeIdx: uniqueIndex("ai_workforce_tasks_workspace_code_unique_idx").on(table.workspaceId, table.taskCode),
    aiTaskWorkspaceStatusIdx: index("ai_workforce_tasks_workspace_status_idx").on(table.workspaceId, table.status),
    aiTaskEmployeeIdx: index("ai_workforce_tasks_employee_idx").on(table.assignedEmployeeId),
  }),
);

export const aiWorkforceActivityLogs = pgTable(
  "ai_workforce_activity_logs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    employeeId: uuid("employee_id").references(() => aiWorkforceEmployees.id, { onDelete: "set null" }),
    taskId: uuid("task_id").references(() => aiWorkforceTasks.id, { onDelete: "set null" }),
    eventType: text("event_type").notNull(),
    description: text("description").notNull(),
    metadata: jsonb("metadata").$type<Record<string, string | number | boolean>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    aiActivityWorkspaceIdx: index("ai_workforce_activity_workspace_idx").on(table.workspaceId),
    aiActivityEmployeeIdx: index("ai_workforce_activity_employee_idx").on(table.employeeId),
  }),
);

export const humanEmployees = pgTable(
  "human_employees",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    employeeCode: text("employee_code").notNull(),
    name: text("name").notNull(),
    department: text("department").notNull(),
    role: text("role").notNull(),
    status: text("status").notNull().default("Available"),
    permissions: jsonb("permissions").$type<string[]>().notNull().default([]),
    managerUserId: uuid("manager_user_id").references(() => users.id, { onDelete: "set null" }),
    aiCollaborationMode: text("ai_collaboration_mode").notNull().default("Hybrid"),
    performanceScore: integer("performance_score").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    humanEmployeeUniqueIdx: uniqueIndex("human_employees_workspace_code_unique_idx").on(table.workspaceId, table.employeeCode),
    humanEmployeeDepartmentIdx: index("human_employees_workspace_department_idx").on(table.workspaceId, table.department),
  }),
);

export const aiApprovalCenterItems = pgTable(
  "ai_approval_center_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").notNull().references(() => workspaces.id, { onDelete: "cascade" }),
    taskId: uuid("task_id").references(() => aiWorkforceTasks.id, { onDelete: "set null" }),
    requestedByEmployeeId: uuid("requested_by_employee_id").references(() => aiWorkforceEmployees.id, { onDelete: "set null" }),
    actionType: text("action_type").notNull(),
    title: text("title").notNull(),
    preview: text("preview").notNull(),
    riskLevel: text("risk_level").notNull().default("medium"),
    status: text("status").notNull().default("Waiting Approval"),
    allowedActions: jsonb("allowed_actions").$type<string[]>().notNull().default(["Approve", "Reject", "Edit", "Retry"]),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    approvalCenterWorkspaceIdx: index("ai_approval_center_workspace_status_idx").on(table.workspaceId, table.status),
  }),
);

export const productionReadinessItems = pgTable(
  "production_readiness_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").references(() => workspaces.id, { onDelete: "cascade" }),
    itemKey: text("item_key").notNull(),
    category: text("category").notNull(),
    name: text("name").notNull(),
    statusLabel: text("status_label").notNull().default("NO DATA"),
    evidence: text("evidence").notNull().default("Only shown when actual infrastructure/configuration is available."),
    recommendations: jsonb("recommendations").$type<string[]>().notNull().default([]),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    readinessIdx: uniqueIndex("production_readiness_workspace_key_unique_idx").on(table.workspaceId, table.itemKey),
    readinessCategoryIdx: index("production_readiness_category_idx").on(table.category),
  }),
);

export const universalActionOptions = pgTable(
  "universal_action_options",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    actionType: text("action_type").notNull(),
    optionKey: text("option_key").notNull(),
    label: text("label").notNull(),
    supportedFormats: jsonb("supported_formats").$type<string[]>().notNull().default([]),
    flow: jsonb("flow").$type<string[]>().notNull().default([]),
    requiredPermission: text("required_permission").notNull().default("workspace.read"),
    approvalRequired: boolean("approval_required").notNull().default(false),
    enabled: boolean("enabled").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    actionOptionIdx: uniqueIndex("universal_action_options_type_key_unique_idx").on(table.actionType, table.optionKey),
  }),
);

export const globalizationSettings = pgTable(
  "globalization_settings",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    languages: jsonb("languages").$type<string[]>().notNull().default([]),
    currencies: jsonb("currencies").$type<string[]>().notNull().default([]),
    timezones: jsonb("timezones").$type<string[]>().notNull().default([]),
    dateFormats: jsonb("date_formats").$type<string[]>().notNull().default([]),
    numberFormats: jsonb("number_formats").$type<string[]>().notNull().default([]),
    countrySettings: jsonb("country_settings").$type<string[]>().notNull().default([]),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    globalizationWorkspaceIdx: uniqueIndex("globalization_settings_workspace_unique_idx").on(table.workspaceId),
  }),
);

export const whiteLabelSettings = pgTable(
  "white_label_settings",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    logoUrl: text("logo_url"),
    brandName: text("brand_name").notNull(),
    domain: text("domain"),
    clientPortalBranding: boolean("client_portal_branding").notNull().default(true),
    reportBranding: boolean("report_branding").notNull().default(true),
    emailBranding: boolean("email_branding").notNull().default(true),
    theme: jsonb("theme").$type<Record<string, string | number | boolean>>().notNull().default({}),
    statusLabel: text("status_label").notNull().default("CONFIGURED"),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    whiteLabelWorkspaceIdx: uniqueIndex("white_label_settings_workspace_unique_idx").on(table.workspaceId),
  }),
);

export const aiMemoryItems = pgTable(
  "ai_memory_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    userId: uuid("user_id").references(() => users.id, { onDelete: "cascade" }),
    memoryType: text("memory_type").notNull(),
    title: text("title").notNull(),
    summary: text("summary").notNull(),
    controls: jsonb("controls").$type<string[]>().notNull().default(["View", "Edit", "Delete", "Disable"]),
    enabled: boolean("enabled").notNull().default(true),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    aiMemoryWorkspaceIdx: index("ai_memory_workspace_type_idx").on(table.workspaceId, table.memoryType),
  }),
);

export const humanApprovalPolicies = pgTable(
  "human_approval_policies",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id")
      .notNull()
      .references(() => workspaces.id, { onDelete: "cascade" }),
    operationKey: text("operation_key").notNull(),
    label: text("label").notNull(),
    flow: jsonb("flow").$type<string[]>().notNull().default(["AI Draft", "Human Review", "Approval", "Action"]),
    required: boolean("required").notNull().default(true),
    riskLevel: text("risk_level").notNull().default("medium"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    approvalPolicyIdx: uniqueIndex("human_approval_workspace_operation_unique_idx").on(table.workspaceId, table.operationKey),
  }),
);

export const finalStructureSections = pgTable(
  "final_structure_sections",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    sectionKey: text("section_key").notNull(),
    icon: text("icon").notNull(),
    title: text("title").notNull(),
    modules: jsonb("modules").$type<string[]>().notNull().default([]),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    finalStructureIdx: uniqueIndex("final_structure_sections_key_unique_idx").on(table.sectionKey),
  }),
);

export const platformMetrics = pgTable(
  "platform_metrics",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    metricKey: text("metric_key").notNull(),
    label: text("label").notNull(),
    value: integer("value").notNull().default(0),
    unit: text("unit").notNull().default("count"),
    trend: text("trend").notNull().default("stable"),
    visibleToSuperOwner: boolean("visible_to_super_owner").notNull().default(true),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    metricIdx: uniqueIndex("platform_metrics_key_unique_idx").on(table.metricKey),
  }),
);

export const systemHealthChecks = pgTable(
  "system_health_checks",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    componentKey: text("component_key").notNull(),
    displayName: text("display_name").notNull(),
    status: genericStatusEnum("status").notNull().default("active"),
    uptimePercent: integer("uptime_percent").notNull().default(100),
    lastCheckedAt: timestamp("last_checked_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    componentIdx: uniqueIndex("system_health_checks_component_unique_idx").on(table.componentKey),
  }),
);

export const featureFlags = pgTable(
  "feature_flags",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    flagKey: text("flag_key").notNull(),
    name: text("name").notNull(),
    enabled: boolean("enabled").notNull().default(false),
    rolloutPercent: integer("rollout_percent").notNull().default(0),
    requiredPlan: planTierEnum("required_plan"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    flagIdx: uniqueIndex("feature_flags_key_unique_idx").on(table.flagKey),
  }),
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    workspaceId: uuid("workspace_id").references(() => workspaces.id, { onDelete: "cascade" }),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    actorType: auditActorTypeEnum("actor_type").notNull().default("system"),
    eventType: text("event_type").notNull(),
    description: text("description").notNull(),
    riskLevel: text("risk_level").notNull().default("low"),
    metadata: jsonb("metadata").$type<Record<string, string | number | boolean>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    auditWorkspaceIdx: index("audit_logs_workspace_idx").on(table.workspaceId),
    auditEventIdx: index("audit_logs_event_idx").on(table.eventType),
  }),
);

export const usersRelations = relations(users, ({ many, one }) => ({
  credentials: one(authCredentials),
  tokens: many(authTokens),
  profile: one(userProfiles),
  onboardingPreferences: many(onboardingPreferences),
  ownedWorkspaces: many(workspaces),
  memberships: many(workspaceMembers),
  sessions: many(sessions),
  devices: many(trustedDevices),
  securitySettings: one(securitySettings),
}));

export const workspacesRelations = relations(workspaces, ({ one, many }) => ({
  owner: one(users, {
    fields: [workspaces.ownerUserId],
    references: [users.id],
  }),
  members: many(workspaceMembers),
  subscription: one(subscriptions),
  usageMeters: many(usageMeters),
  invoices: many(invoices),
  onboardingItems: many(onboardingItems),
  onboardingPreferences: many(onboardingPreferences),
  businessProfile: one(businessProfiles),
  catalogItems: many(businessCatalogItems),
  clients: many(crmClients),
  leads: many(crmLeads),
  projects: many(projects),
  tasks: many(tasks),
  operations: many(businessOperations),
  aiOutputs: many(aiOutputs),
  osCapabilities: many(osCapabilities),
  workflowTemplates: many(workflowTemplates),
  aiCommandRuns: many(aiCommandRuns),
  customAiAgents: many(customAiAgents),
  knowledgeDocuments: many(knowledgeDocuments),
  trackingMatrixEvents: many(trackingMatrixEvents),
  affiliatePrograms: many(affiliatePrograms),
  cpaCampaigns: many(cpaCampaigns),
  brandVoiceProfile: one(brandVoiceProfiles),
  contentRepurposingPlans: many(contentRepurposingPlans),
  creativeStudioProjects: many(creativeStudioProjects),
  dataOperations: many(dataOperations),
  officeAssets: many(officeAssets),
  calendarEvents: many(calendarEvents),
  remoteMeetings: many(remoteMeetings),
  agentOrchestrationRuns: many(agentOrchestrationRuns),
  leadCompanies: many(leadCompanies),
  leadContacts: many(leadContacts),
  leadRecords: many(leadRecords),
  leadPipelineStages: many(leadPipelineStages),
  websiteAudits: many(websiteAudits),
  auditFindings: many(auditFindings),
  leadOpportunities: many(leadOpportunities),
  outreachMessages: many(outreachMessages),
  leadActivities: many(leadActivities),
  leadNotes: many(leadNotes),
  salesDeals: many(salesDeals),
  outreachCampaigns: many(outreachCampaigns),
  automationWorkflows: many(automationWorkflows),
  leadFiles: many(leadFiles),
  aiProcessingJobs: many(aiProcessingJobs),
  leadNotifications: many(leadNotifications),
  leadPlatformIntegrations: many(leadPlatformIntegrations),
  leadReports: many(leadReports),
  suppressionEntries: many(suppressionEntries),
  jarvisCommandCenterRuns: many(jarvisCommandCenterRuns),
  n8nBackboneWorkflows: many(n8nBackboneWorkflows),
  meetingIntelligenceSessions: many(meetingIntelligenceSessions),
  businessProducts: many(businessProducts),
  businessFinanceEntries: many(businessFinanceEntries),
  backlinkWorkLogs: many(backlinkWorkLogs),
  serverJarvisSnapshots: many(serverJarvisSnapshots),
  aiWorkforceEmployees: many(aiWorkforceEmployees),
  aiWorkforceTasks: many(aiWorkforceTasks),
  aiWorkforceActivityLogs: many(aiWorkforceActivityLogs),
  humanEmployees: many(humanEmployees),
  aiApprovalCenterItems: many(aiApprovalCenterItems),
  productionReadinessItems: many(productionReadinessItems),
  globalizationSettings: one(globalizationSettings),
  whiteLabelSettings: one(whiteLabelSettings),
  aiMemoryItems: many(aiMemoryItems),
  humanApprovalPolicies: many(humanApprovalPolicies),
  voiceAiConfig: one(voiceAiConfigs),
  translationConfig: one(translationConfigs),
  meetingConfig: one(meetingConfigs),
  integrations: many(integrations),
  apiKeys: many(apiKeys),
  auditLogs: many(auditLogs),
}));

export const workspaceMembersRelations = relations(workspaceMembers, ({ one }) => ({
  user: one(users, {
    fields: [workspaceMembers.userId],
    references: [users.id],
  }),
  workspace: one(workspaces, {
    fields: [workspaceMembers.workspaceId],
    references: [workspaces.id],
  }),
}));

export const plansRelations = relations(plans, ({ many }) => ({
  entitlements: many(planEntitlements),
  subscriptions: many(subscriptions),
}));

export const planEntitlementsRelations = relations(planEntitlements, ({ one }) => ({
  plan: one(plans, {
    fields: [planEntitlements.planId],
    references: [plans.id],
  }),
}));

export const subscriptionsRelations = relations(subscriptions, ({ one }) => ({
  workspace: one(workspaces, {
    fields: [subscriptions.workspaceId],
    references: [workspaces.id],
  }),
  plan: one(plans, {
    fields: [subscriptions.planId],
    references: [plans.id],
  }),
}));

export const securitySettingsRelations = relations(securitySettings, ({ one }) => ({
  user: one(users, {
    fields: [securitySettings.userId],
    references: [users.id],
  }),
}));
