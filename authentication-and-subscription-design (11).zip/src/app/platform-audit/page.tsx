import type { ReactNode } from "react";
import Image from "next/image";
import Link from "next/link";
import { getDeepHealthSnapshot, getGapAnalysis, getLiveMonitoringSnapshot } from "@/lib/platform-observability";

export const dynamic = "force-dynamic";

function Card({ title, children }: { title: string; children: ReactNode }) {
  return <section className="glass-panel rounded-[2rem] p-6"><h2 className="text-2xl font-black">{title}</h2>{children}</section>;
}

function Pill({ children, tone = "gold" }: { children: ReactNode; tone?: "gold" | "green" | "red" | "slate" }) {
  const tones = {
    gold: "border-yellow-200/25 bg-yellow-200/10 text-yellow-100",
    green: "border-emerald-300/25 bg-emerald-400/10 text-emerald-100",
    red: "border-rose-300/25 bg-rose-400/10 text-rose-100",
    slate: "border-white/15 bg-white/[0.055] text-white/70",
  };
  return <span className={`rounded-full border px-3 py-1 text-xs font-bold ${tones[tone]}`}>{children}</span>;
}

function statusTone(status: string | number) {
  const text = String(status);
  if (["Operational", "Connected", "CONFIGURED", "Configured"].some((item) => text.includes(item))) return "green" as const;
  if (["Down", "Error", "Failed"].some((item) => text.includes(item))) return "red" as const;
  if (["Not Configured", "Integration Required", "NO DATA", "AUTHORIZATION REQUIRED"].some((item) => text.includes(item))) return "gold" as const;
  return "slate" as const;
}

export default async function PlatformAuditPage() {
  const [gap, health, monitoring] = await Promise.all([getGapAnalysis(), getDeepHealthSnapshot(), getLiveMonitoringSnapshot()]);

  return (
    <main className="min-h-screen px-5 py-5 md:px-8">
      <div className="mx-auto max-w-7xl space-y-5">
        <nav className="glass-panel flex flex-col justify-between gap-4 rounded-[2rem] p-5 md:flex-row md:items-center">
          <Link href="/" className="flex items-center gap-3">
            <Image src="/foysal-it-mark.svg" alt="FOYSAL IT" width={48} height={48} className="rounded-2xl" />
            <div>
              <p className="font-black tracking-[0.18em]">FOYSAL IT · BUILD AUDIT</p>
              <p className="text-sm text-white/50">Working · Missing · Integration Required · Next Build</p>
            </div>
          </Link>
          <div className="flex flex-wrap gap-2">
            <Link href="/professional-review" className="rounded-full border border-yellow-200/25 bg-yellow-200/10 px-4 py-2 text-sm font-bold text-yellow-100">Professional Review</Link>
            <Link href="/lead-intelligence" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">Lead Intelligence</Link>
            <Link href="/jarvis" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">Jarvis</Link>
            <a href="/api/platform/gap-analysis" className="rounded-full bg-white px-4 py-2 text-sm font-black text-[#250022]">Audit API</a>
          </div>
        </nav>

        <section className="glass-panel rounded-[2rem] p-7 md:p-9">
          <p className="text-xs font-bold uppercase tracking-[0.34em] text-yellow-200/75">10x engineering review</p>
          <h1 className="mt-3 text-5xl font-black tracking-[-0.055em] md:text-7xl">What is done, what is missing, and what needs real integrations.</h1>
          <p className="mt-5 max-w-4xl text-white/65">FOYSAL IT OS is updated as one connected SaaS product. This page does not fake progress: connected features work through PostgreSQL/runtime/fetch capabilities, while external services are clearly marked Integration Required.</p>
          <div className="mt-6 grid gap-3 md:grid-cols-6">
            {Object.entries(gap.counts).map(([key, value]) => <div key={key} className="rounded-2xl border border-white/10 bg-black/20 p-4"><p className="text-xs uppercase tracking-[0.18em] text-white/35">{key}</p><p className="mt-2 text-3xl font-black">{value}</p></div>)}
          </div>
        </section>

        <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
          <Card title="Already Working">
            <div className="mt-5 space-y-2">{gap.alreadyWorking.map((item) => <p key={item} className="rounded-2xl border border-emerald-300/15 bg-emerald-400/10 p-3 text-sm text-emerald-50">✓ {item}</p>)}</div>
          </Card>
          <Card title="Integration Required">
            <div className="mt-5 space-y-2">{gap.integrationRequired.map((item) => <p key={item} className="rounded-2xl border border-yellow-200/15 bg-yellow-200/10 p-3 text-sm text-yellow-50">⚠ {item}</p>)}</div>
          </Card>
        </div>

        <Card title="Recommended Next Build">
          <div className="mt-5 grid gap-3 md:grid-cols-2">{gap.recommendedNextBuild.map((item) => <p key={item} className="rounded-2xl border border-white/10 bg-black/20 p-3 text-sm text-white/70">→ {item}</p>)}</div>
        </Card>

        <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
          <Card title="Reliable Near Real-Time Monitoring">
            <p className="mt-2 text-sm text-white/55">Window: {monitoring.window}. Values come from database tables; unavailable telemetry displays NO DATA.</p>
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              {monitoring.metrics.map((metric) => <div key={metric.label} className="rounded-2xl border border-white/10 bg-black/20 p-4"><div className="flex items-center justify-between gap-3"><p className="font-bold">{metric.label}</p><Pill tone={statusTone(metric.value)}>{metric.value}</Pill></div><p className="mt-2 text-xs text-white/45">Source: {metric.source}</p></div>)}
            </div>
          </Card>

          <Card title="System Health">
            <p className="mt-2 text-sm text-white/55">Statuses: Operational / Degraded / Down / Unknown / Not Configured.</p>
            <div className="mt-5 space-y-3">
              {health.checks.map((check) => <div key={check.component} className="rounded-2xl border border-white/10 bg-black/20 p-4"><div className="flex items-center justify-between gap-3"><p className="font-bold">{check.component}</p><Pill tone={statusTone(check.status)}>{check.status}</Pill></div><p className="mt-2 text-sm text-white/50">{check.evidence}</p></div>)}
            </div>
          </Card>
        </div>

        <Card title="Final Engineering Rule">
          <div className="mt-5 rounded-3xl border border-yellow-200/20 bg-yellow-200/10 p-5">
            <p className="text-xl font-black text-yellow-100">{gap.principle}</p>
            <p className="mt-3 text-white/65">No fake connected status, no fake AI response, no fake meeting translation, no fake Google Sheets/private API data, no fake server recovery, no fake payment, and no fake API success.</p>
          </div>
        </Card>
      </div>
    </main>
  );
}
