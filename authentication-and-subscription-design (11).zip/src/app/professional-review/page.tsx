import type { ReactNode } from "react";
import Image from "next/image";
import Link from "next/link";
import { getProfessionalStrategyAudit } from "@/lib/strategy-audit";

export const dynamic = "force-dynamic";

function Card({ title, children }: { title: string; children: ReactNode }) {
  return <section className="glass-panel rounded-[2rem] p-6"><h2 className="text-2xl font-black">{title}</h2>{children}</section>;
}

function Pill({ children, tone = "gold" }: { children: ReactNode; tone?: "gold" | "green" | "red" | "slate" }) {
  const tones = {
    gold: "border-yellow-200/25 bg-yellow-200/10 text-yellow-100",
    green: "border-emerald-300/25 bg-emerald-400/10 text-emerald-100",
    red: "border-rose-300/25 bg-rose-400/10 text-rose-100",
    slate: "border-white/15 bg-white/[0.055] text-white/70",
  };
  return <span className={`rounded-full border px-3 py-1 text-xs font-bold ${tones[tone]}`}>{children}</span>;
}

function tone(status: string) {
  if (/working|configured|ready|operational/i.test(status)) return "green" as const;
  if (/required|partial|needs|not configured/i.test(status)) return "gold" as const;
  if (/error|down|failed/i.test(status)) return "red" as const;
  return "slate" as const;
}

export default async function ProfessionalReviewPage() {
  const audit = await getProfessionalStrategyAudit();

  return (
    <main className="min-h-screen px-5 py-5 md:px-8">
      <div className="mx-auto max-w-7xl space-y-5">
        <nav className="glass-panel flex flex-col justify-between gap-4 rounded-[2rem] p-5 md:flex-row md:items-center">
          <Link href="/" className="flex items-center gap-3">
            <Image src="/foysal-it-mark.svg" alt="FOYSAL IT" width={48} height={48} className="rounded-2xl" />
            <div><p className="font-black tracking-[0.18em]">FOYSAL IT · PROFESSIONAL REVIEW</p><p className="text-sm text-white/50">Missing · Update · Premium · Market Demand</p></div>
          </Link>
          <div className="flex flex-wrap gap-2">
            <Link href="/test-center" className="rounded-full border border-yellow-200/25 bg-yellow-200/10 px-4 py-2 text-sm font-bold text-yellow-100">Test Center</Link>
            <Link href="/subscription-launch" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">Subscription</Link>
            <Link href="/ai-workforce" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">AI Workforce</Link>
            <Link href="/lead-intelligence" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">Lead App</Link>
            <a href="/api/platform/strategy-audit" className="rounded-full bg-white px-4 py-2 text-sm font-black text-[#250022]">Review API</a>
          </div>
        </nav>

        <section className="glass-panel rounded-[2rem] p-7 md:p-10">
          <p className="text-xs font-bold uppercase tracking-[0.34em] text-yellow-200/75">Repository-inspired 10x audit</p>
          <h1 className="mt-3 max-w-5xl text-5xl font-black tracking-[-0.055em] md:text-7xl">কি আছে, কি missing, কি update করলে app premium/professional হবে।</h1>
          <p className="mt-5 max-w-4xl text-lg leading-8 text-white/65">I reviewed your requested repo/file structure conceptually and compared it with this app. The app already has real database/import/audit/Jarvis/workforce foundations, but 100% production needs permanent domain config, real integrations, payment adapter, richer UX pages, exports, and native/PWA distribution polish.</p>
          <div className="mt-6 rounded-3xl border border-yellow-200/20 bg-yellow-200/10 p-5"><p className="font-black text-yellow-100">Verdict</p><p className="mt-2 text-white/70">{audit.verdict}</p></div>
        </section>

        <Card title="Repo / Existing App Gap Coverage">
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            {audit.repoInspiredCoverage.map((item) => <div key={item.area} className="rounded-2xl border border-white/10 bg-black/20 p-4"><div className="flex items-center justify-between gap-3"><p className="font-bold">{item.area}</p><Pill tone={tone(item.status)}>{item.status}</Pill></div><p className="mt-2 text-sm text-white/55">{item.current}</p></div>)}
          </div>
        </Card>

        <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
          <Card title="Best Professional Updates Next">
            <div className="mt-5 space-y-2">{audit.professionalUpdates.map((item) => <p key={item} className="rounded-2xl border border-white/10 bg-white/[0.045] p-3 text-sm text-white/72">→ {item}</p>)}</div>
          </Card>
          <Card title="Market Demand">
            <div className="mt-5 space-y-3">{audit.marketDemand.map((item) => <div key={item.segment} className="rounded-2xl border border-white/10 bg-black/20 p-4"><div className="flex items-center justify-between gap-3"><p className="font-bold">{item.segment}</p><Pill tone="green">{item.demand}</Pill></div><p className="mt-2 text-sm text-white/55">{item.why}</p></div>)}</div>
          </Card>
        </div>

        <div className="grid gap-5 lg:grid-cols-3">
          <Card title="Permanent Domain Fix">
            <div className="mt-5 space-y-3 text-sm text-white/65">
              <p>APP URL: {audit.domain.appUrl ?? "Not set"}</p>
              <p>API URL: {audit.domain.apiUrl ?? "Not set"}</p>
              <p>OAuth Callback: {audit.domain.oauthCallbackUrl ?? "Not set"}</p>
              <Pill tone={audit.domain.permanentDomainConfigured ? "green" : "gold"}>{audit.domain.permanentDomainConfigured ? "Configured" : "Needs Production Env"}</Pill>
            </div>
          </Card>
          <Card title="Payment API GET">
            <div className="mt-5 space-y-3"><Pill tone={tone(audit.payment.status)}>{audit.payment.status}</Pill><p className="text-sm text-white/60">Active provider: {audit.payment.activeProvider ?? "None"}</p><a href="/api/billing/payment-status" className="inline-flex rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">Open Payment Status API</a></div>
          </Card>
          <Card title="Windows · iOS · Android · Offline">
            <div className="mt-5 space-y-2">{Object.entries(audit.apps).map(([platform, value]) => <div key={platform} className="rounded-2xl border border-white/10 bg-black/20 p-3"><div className="flex items-center justify-between gap-2"><p className="font-bold capitalize">{platform}</p><Pill tone={tone(value.status)}>{value.status}</Pill></div><p className="mt-1 text-xs text-white/45">{value.note}</p></div>)}</div>
          </Card>
        </div>

        <Card title="Design Advice — Premium, Less Text, Same Identity">
          <div className="mt-5 grid gap-3 md:grid-cols-3">
            {[
              "Keep purple/yellow FOYSAL IT identity but reduce long text blocks.",
              "Use KPI cards, workflow diagrams, screenshots and short proof sections.",
              "Make homepage closer to premium SaaS landing style: hero, outcomes, product screenshots, modules, proof, CTA.",
              "Use responsive cards instead of wide text-heavy tables on mobile.",
              "Add loading/empty/error states to every important action.",
              "Keep public marketing pages SEO-ready, but move deep technical detail into docs/audit pages.",
            ].map((item) => <p key={item} className="rounded-2xl border border-white/10 bg-black/20 p-4 text-sm text-white/70">{item}</p>)}
          </div>
        </Card>
      </div>
    </main>
  );
}
