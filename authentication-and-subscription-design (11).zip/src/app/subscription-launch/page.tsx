import type { ReactNode } from "react";
import Image from "next/image";
import Link from "next/link";
import { getSubscriptionSalesReadiness } from "@/lib/launch-readiness";

export const dynamic = "force-dynamic";

function Card({ title, children }: { title: string; children: ReactNode }) {
  return <section className="glass-panel rounded-[2rem] p-6"><h2 className="text-2xl font-black">{title}</h2>{children}</section>;
}

function Pill({ children, tone = "gold" }: { children: ReactNode; tone?: "green" | "gold" | "slate" }) {
  const tones = {
    green: "border-emerald-300/25 bg-emerald-400/10 text-emerald-100",
    gold: "border-yellow-200/25 bg-yellow-200/10 text-yellow-100",
    slate: "border-white/15 bg-white/[0.055] text-white/70",
  };
  return <span className={`rounded-full border px-3 py-1 text-xs font-bold ${tones[tone]}`}>{children}</span>;
}

export default async function SubscriptionLaunchPage() {
  const readiness = await getSubscriptionSalesReadiness();

  return (
    <main className="min-h-screen px-5 py-5 md:px-8">
      <div className="mx-auto max-w-7xl space-y-5">
        <nav className="glass-panel flex flex-col justify-between gap-4 rounded-[2rem] p-5 md:flex-row md:items-center">
          <Link href="/" className="flex items-center gap-3">
            <Image src="/foysal-it-mark.svg" alt="FOYSAL IT" width={48} height={48} className="rounded-2xl" />
            <div><p className="font-black tracking-[0.18em]">FOYSAL IT · SUBSCRIPTION LAUNCH</p><p className="text-sm text-white/50">Sell Readiness · Plans · Payment · Legal · Security</p></div>
          </Link>
          <div className="flex flex-wrap gap-2">
            <Link href="/test-center" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">Test Center</Link>
            <a href="/api/platform/subscription-sales-readiness" className="rounded-full bg-white px-4 py-2 text-sm font-black text-[#250022]">Sales API</a>
          </div>
        </nav>

        <section className="glass-panel rounded-[2rem] p-7 md:p-10">
          <p className="text-xs font-bold uppercase tracking-[0.34em] text-yellow-200/75">Subscription business model</p>
          <h1 className="mt-3 max-w-5xl text-5xl font-black tracking-[-0.055em] md:text-7xl">FOYSAL IT can be sold as subscription, but public paid launch needs payment/domain/legal/email setup.</h1>
          <p className="mt-5 max-w-4xl text-lg leading-8 text-white/65">You can start with manual beta/founder-led sales now, clearly explaining limits. For automated online subscription checkout, configure and test payment provider, domain, email, security, and policies first.</p>
          <div className="mt-6 rounded-3xl border border-yellow-200/20 bg-yellow-200/10 p-5"><p className="font-black text-yellow-100">Recommended now</p><p className="mt-2 text-white/70">{readiness.recommendedSellingModeNow}</p></div>
        </section>

        <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
          <Card title="Packaged Subscription Plans">
            <div className="mt-5 space-y-3">
              {readiness.packagedPlans.map((plan) => <div key={plan.name} className="rounded-2xl border border-white/10 bg-black/20 p-4"><div className="flex items-center justify-between gap-3"><p className="font-bold">{plan.name}</p><Pill tone={plan.sellable ? "green" : "gold"}>{plan.sellable ? "Sellable with limits" : "Needs integrations"}</Pill></div><p className="mt-2 text-sm text-white/55">Target: {plan.target}</p><p className="text-sm text-white/55">Limit: {plan.limit}</p><p className="mt-2 text-xs text-yellow-100">{plan.note}</p></div>)}
            </div>
          </Card>
          <Card title="Proof You Can Show Buyers">
            <div className="mt-5 space-y-2">{readiness.proofYouCanShow.map((item) => <p key={item} className="rounded-2xl border border-emerald-300/15 bg-emerald-400/10 p-3 text-sm text-emerald-50">✓ {item}</p>)}</div>
            <div className="mt-5 grid gap-3 md:grid-cols-2"><Pill tone={readiness.payment.status === "Configured - Test Required" ? "green" : "gold"}>Payment: {readiness.payment.status}</Pill><Pill tone={readiness.domain.permanentDomainConfigured ? "green" : "gold"}>Domain: {readiness.domain.permanentDomainConfigured ? "Configured" : "Needs Env"}</Pill></div>
          </Card>
        </div>

        <Card title="Must Finish Before Public Paid Launch">
          <div className="mt-5 grid gap-3 md:grid-cols-2">{readiness.mustFinishBeforePublicPaidLaunch.map((item) => <p key={item} className="rounded-2xl border border-yellow-200/20 bg-yellow-200/10 p-4 text-sm text-yellow-50">⚠ {item}</p>)}</div>
        </Card>

        <Card title="License / Policy Pack Needed">
          <div className="mt-5 grid gap-3 md:grid-cols-3">
            {["Terms of Service", "Privacy Policy", "Refund Policy", "Acceptable Use Policy", "AI Disclaimer", "Data Processing Agreement", "Email/WhatsApp Compliance", "Security Policy", "SLA for Enterprise"].map((item) => <p key={item} className="rounded-2xl border border-white/10 bg-black/20 p-4 text-sm text-white/72">{item}</p>)}
          </div>
        </Card>
      </div>
    </main>
  );
}
