import Image from "next/image";
import Link from "next/link";

export default function OfflinePage() {
  return (
    <main className="grid min-h-screen place-items-center px-6 py-10">
      <section className="glass-panel max-w-xl rounded-[2rem] p-8 text-center">
        <Image src="/foysal-it-mark.svg" alt="FOYSAL IT" width={76} height={76} className="mx-auto rounded-3xl" />
        <p className="mt-6 text-xs font-bold uppercase tracking-[0.34em] text-yellow-200/75">Offline Shell</p>
        <h1 className="mt-3 text-4xl font-black tracking-[-0.04em]">FOYSAL IT OS is offline.</h1>
        <p className="mt-4 text-white/65">
          The installable app shell is available, but live leads, audits, AI workforce, Jarvis, database actions and integrations require network access.
        </p>
        <Link href="/" className="mt-6 inline-flex rounded-full bg-white px-6 py-3 text-sm font-black text-[#250022]">
          Retry Home
        </Link>
      </section>
    </main>
  );
}
