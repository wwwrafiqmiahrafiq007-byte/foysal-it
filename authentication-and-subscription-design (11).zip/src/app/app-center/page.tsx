import type { ReactNode } from "react";
import Image from "next/image";
import Link from "next/link";
import { InstallPwaButton } from "@/components/InstallPwaButton";
import { getDistributionOverview } from "@/lib/distribution-center";

export const dynamic = "force-dynamic";

function Card({ title, children }: { title: string; children: ReactNode }) {
  return <section className="glass-panel rounded-[2rem] p-6"><h2 className="text-2xl font-black">{title}</h2>{children}</section>;
}

function Pill({ children, tone = "gold" }: { children: ReactNode; tone?: "gold" | "green" | "slate" }) {
  const tones = {
    gold: "border-yellow-200/25 bg-yellow-200/10 text-yellow-100",
    green: "border-emerald-300/25 bg-emerald-400/10 text-emerald-100",
    slate: "border-white/15 bg-white/[0.055] text-white/70",
  };
  return <span className={`rounded-full border px-3 py-1 text-xs font-bold ${tones[tone]}`}>{children}</span>;
}

function tone(status: string) {
  return /working|configured|available/i.test(status) ? "green" : /future|required|limitations/i.test(status) ? "gold" : "slate";
}

export default function AppCenterPage() {
  const overview = getDistributionOverview();

  return (
    <main className="min-h-screen px-5 py-5 md:px-8">
      <div className="mx-auto max-w-7xl space-y-5">
        <nav className="glass-panel flex flex-col justify-between gap-4 rounded-[2rem] p-5 md:flex-row md:items-center">
          <Link href="/" className="flex items-center gap-3">
            <Image src="/foysal-it-mark.svg" alt="FOYSAL IT" width={48} height={48} className="rounded-2xl" />
            <div><p className="font-black tracking-[0.18em]">FOYSAL IT · APP CENTER</p><p className="text-sm text-white/50">Windows · PC · PWA · Extension · Income Roadmap</p></div>
          </Link>
          <div className="flex flex-wrap gap-2">
            <Link href="/professional-review" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">Review</Link>
            <a href="/api/platform/distribution-center" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">API</a>
            <a href="/api/download/windows-package" className="rounded-full bg-white px-4 py-2 text-sm font-black text-[#250022]">Download ZIP</a>
          </div>
        </nav>

        <section className="glass-panel rounded-[2rem] p-7 md:p-10">
          <p className="text-xs font-bold uppercase tracking-[0.34em] text-yellow-200/75">FOYSAL IT owner app distribution</p>
          <h1 className="mt-3 max-w-5xl text-5xl font-black tracking-[-0.055em] md:text-7xl">Windows/laptop/PC package, PWA install, extension starter, and 50+ future upgrades.</h1>
          <p className="mt-5 max-w-4xl text-lg leading-8 text-white/65">This page gives a real downloadable install/deployment ZIP. Native app store releases, Chrome extension publishing, offline database sync, payment checkout and Google/n8n integrations remain future/integration-required until configured, signed and tested.</p>
        </section>

        <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
          <Card title="Real Download Package">
            <div className="mt-5 space-y-3">
              <InstallPwaButton compact />
              {overview.downloads.map((download) => <div key={download.name} className="rounded-2xl border border-white/10 bg-black/20 p-4"><div className="flex items-center justify-between gap-3"><p className="font-bold">{download.name}</p><Pill tone={tone(download.status)}>{download.status}</Pill></div><a href={download.url} className="mt-3 inline-flex rounded-full border border-yellow-200/25 px-4 py-2 text-sm font-bold text-yellow-100">Download / Open</a></div>)}
            </div>
          </Card>

          <Card title="Owner / Admin / Moderator">
            <div className="mt-5 space-y-3">
              {overview.ownerAccounts.map((account) => <div key={account.email} className="rounded-2xl border border-white/10 bg-black/20 p-4"><p className="font-bold">{account.role}</p><p className="mt-1 text-yellow-100">{account.email}</p><p className="mt-2 text-sm text-white/55">{account.note}</p></div>)}
            </div>
          </Card>
        </div>

        <Card title="App Types & Device Strategy">
          <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {overview.appTypes.map((item) => <div key={item.type} className="rounded-2xl border border-white/10 bg-white/[0.045] p-4"><div className="flex items-center justify-between gap-3"><p className="font-bold">{item.type}</p><Pill tone={tone(item.status)}>{item.status}</Pill></div></div>)}
          </div>
        </Card>

        <div className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
          <Card title="Income / Monetization Playbook">
            <div className="mt-5 space-y-2">{overview.revenuePlaybook.map((item, index) => <p key={item} className="rounded-2xl border border-emerald-300/15 bg-emerald-400/10 p-3 text-sm text-emerald-50">{index + 1}. {item}</p>)}</div>
          </Card>
          <Card title="50+ Future Features To Become World-Class">
            <div className="mt-5 grid max-h-[42rem] gap-2 overflow-auto md:grid-cols-2">
              {overview.fiftyFutureFeatures.map((item, index) => <p key={item} className="rounded-2xl border border-white/10 bg-black/20 p-3 text-sm text-white/72">{index + 1}. {item}</p>)}
            </div>
          </Card>
        </div>

        <Card title="Still Missing For Full World-Class Production">
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            {overview.missingForWorldClass.map((item) => <p key={item} className="rounded-2xl border border-yellow-200/20 bg-yellow-200/10 p-4 text-sm text-yellow-50">⚠ {item}</p>)}
          </div>
        </Card>
      </div>
    </main>
  );
}
