import type { ReactNode } from "react";
import Image from "next/image";
import Link from "next/link";
import { getFoysalOsSnapshot, getSuperOwnerUser360 } from "@/lib/foysal-os";

export const dynamic = "force-dynamic";

function Card({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="glass-panel rounded-[2rem] p-6">
      <h2 className="text-2xl font-black">{title}</h2>
      {children}
    </section>
  );
}

export default async function SuperOwnerPage() {
  const snapshot = await getFoysalOsSnapshot();
  const user360 = await getSuperOwnerUser360(snapshot.owner.id);

  return (
    <main className="min-h-screen px-5 py-5 md:px-8">
      <div className="mx-auto max-w-7xl space-y-5">
        <nav className="glass-panel flex flex-col justify-between gap-4 rounded-[2rem] p-5 md:flex-row md:items-center">
          <Link href="/" className="flex items-center gap-3">
            <Image src="/foysal-it-mark.svg" alt="FOYSAL IT" width={48} height={48} className="rounded-2xl" />
            <div>
              <p className="font-black tracking-[0.18em]">SUPER OWNER CONTROL</p>
              <p className="text-sm text-white/50">Authorized platform visibility · no secrets exposed</p>
            </div>
          </Link>
          <div className="flex gap-2">
            <Link href="/dashboard" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">Dashboard</Link>
            <Link href="/platform-audit" className="rounded-full border border-yellow-200/25 bg-yellow-200/10 px-4 py-2 text-sm font-bold text-yellow-100">Build Audit</Link>
            <a href="/api/platform/live-monitoring" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">Live Monitoring API</a>
            <a href="/api/platform/overview" className="rounded-full bg-white px-4 py-2 text-sm font-black text-[#250022]">Overview API</a>
          </div>
        </nav>

        <section className="glass-panel rounded-[2rem] p-7 md:p-9">
          <div className="max-w-4xl">
            <p className="text-xs font-bold uppercase tracking-[0.36em] text-yellow-200/75">Unified SaaS administration</p>
            <h1 className="mt-3 text-5xl font-black tracking-[-0.05em] md:text-7xl">Monitor the whole FOYSAL IT OS without leaking secrets.</h1>
            <p className="mt-5 text-lg leading-8 text-white/65">Users, organizations, agencies, clients, subscriptions, revenue, AI usage, storage, sessions, activity, meetings, integrations, APIs, security, errors, audit logs, health, flags, and settings are connected through one audited platform layer.</p>
          </div>
        </section>

        <div className="grid gap-4 md:grid-cols-4">
          <div className="rounded-3xl border border-white/10 bg-white/[0.055] p-5"><p className="text-sm text-white/50">Users</p><p className="mt-2 text-4xl font-black">{snapshot.counts.users}</p></div>
          <div className="rounded-3xl border border-white/10 bg-white/[0.055] p-5"><p className="text-sm text-white/50">Organizations</p><p className="mt-2 text-4xl font-black">{snapshot.counts.workspaces}</p></div>
          <div className="rounded-3xl border border-white/10 bg-white/[0.055] p-5"><p className="text-sm text-white/50">Roles</p><p className="mt-2 text-4xl font-black">{snapshot.roles.length}</p></div>
          <div className="rounded-3xl border border-white/10 bg-white/[0.055] p-5"><p className="text-sm text-white/50">Target Experiences</p><p className="mt-2 text-4xl font-black">{snapshot.targetSegments.length}</p></div>
        </div>

        <div className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
          <Card title="Roles, Permissions & Configuration">
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              {snapshot.roles.map((role) => (
                <div key={role.id} className="rounded-2xl border border-white/10 bg-black/20 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <p className="font-bold">{role.displayName}</p>
                    <span className="text-xs text-white/40">{role.isPlatformRole ? "Platform" : "Workspace"}</span>
                  </div>
                  <p className="mt-2 text-xs text-white/50">{role.permissions.length} permissions · {role.navigation.length} nav items</p>
                </div>
              ))}
            </div>
          </Card>
          <Card title="Administration Coverage">
            <div className="mt-5 flex flex-wrap gap-2">
              {["Users", "Organizations", "Workspaces", "Roles", "Permissions", "Subscriptions", "Billing", "AI Usage", "Storage", "APIs", "Integrations", "Reports", "Security", "Audit Logs", "Errors", "System Health", "Feature Flags", "Configuration"].map((item) => (
                <span key={item} className="rounded-full border border-yellow-200/25 bg-yellow-200/10 px-3 py-1 text-xs font-bold text-yellow-100">{item}</span>
              ))}
            </div>
            <p className="mt-5 rounded-2xl border border-rose-300/20 bg-rose-400/10 p-4 text-sm text-rose-50">Sensitive secrets never appear in normal UI: no passwords, password hashes, API secrets, OAuth secrets, access tokens, refresh tokens, or raw session tokens.</p>
          </Card>
        </div>

        <div className="grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
          <Card title="Platform Metrics">
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              {snapshot.platformMetrics.map((metric) => (
                <div key={metric.id} className="rounded-2xl border border-white/10 bg-black/20 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <p className="font-bold">{metric.label}</p>
                    <span className="text-xs font-bold text-emerald-200">{metric.trend}</span>
                  </div>
                  <p className="mt-2 text-3xl font-black text-yellow-100">{metric.value.toLocaleString()}</p>
                  <p className="text-sm text-white/45">{metric.unit}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card title="System Health">
            <div className="mt-5 space-y-3">
              {snapshot.healthChecks.map((check) => (
                <div key={check.id} className="rounded-2xl border border-white/10 bg-white/[0.045] p-4">
                  <div className="flex items-center justify-between">
                    <p className="font-bold">{check.displayName}</p>
                    <span className={check.status === "warning" ? "text-yellow-100" : "text-emerald-200"}>{check.status}</span>
                  </div>
                  <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-fuchsia-500 to-yellow-300" style={{ width: `${check.uptimePercent}%` }} /></div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="grid gap-5 lg:grid-cols-2">
          <Card title="Feature Flags">
            <div className="mt-5 space-y-3">
              {snapshot.featureFlags.map((flag) => (
                <div key={flag.id} className="rounded-2xl border border-white/10 bg-white/[0.045] p-4">
                  <div className="flex items-center justify-between gap-3">
                    <p className="font-bold">{flag.name}</p>
                    <span className={flag.enabled ? "text-emerald-200" : "text-white/40"}>{flag.enabled ? "Enabled" : "Disabled"}</span>
                  </div>
                  <p className="mt-1 text-sm text-white/50">Rollout {flag.rolloutPercent}% · Required plan {flag.requiredPlan ?? "none"}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card title="User 360°">
            <div className="mt-5 rounded-3xl border border-yellow-200/20 bg-yellow-200/10 p-5">
              <p className="text-sm text-white/55">Selected user</p>
              <p className="mt-1 text-2xl font-black">{user360.user?.displayName}</p>
              <p className="mt-1 text-white/60">{user360.user?.email} · {user360.user?.accountStatus}</p>
              <p className="mt-3 text-sm text-yellow-50">Excluded: {user360.excludedFields.join(", ")}</p>
            </div>
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <div className="rounded-2xl border border-white/10 bg-black/20 p-4"><p className="text-sm text-white/50">Memberships</p><p className="mt-1 text-3xl font-black">{user360.memberships.length}</p></div>
              <div className="rounded-2xl border border-white/10 bg-black/20 p-4"><p className="text-sm text-white/50">Sessions</p><p className="mt-1 text-3xl font-black">{user360.sessions.length}</p></div>
            </div>
            <a href={`/api/super-owner/user-360?userId=${snapshot.owner.id}`} className="mt-4 block rounded-full border border-white/15 px-4 py-3 text-center text-sm font-black text-white/75">Open sanitized User 360 API</a>
          </Card>
        </div>

        <Card title="Security & Audit Logs">
          <div className="mt-5 grid gap-3 lg:grid-cols-2">
            {snapshot.auditLogs.slice(0, 8).map((log) => (
              <div key={log.id} className="rounded-2xl border border-white/10 bg-black/20 p-4">
                <div className="flex items-center justify-between gap-3">
                  <p className="font-bold">{log.eventType}</p>
                  <span className="text-xs uppercase tracking-[0.2em] text-white/35">{log.riskLevel}</span>
                </div>
                <p className="mt-2 text-sm text-white/55">{log.description}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </main>
  );
}
