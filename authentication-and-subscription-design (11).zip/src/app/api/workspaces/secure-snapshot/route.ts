import { getWorkspaceSecureSnapshot } from "@/lib/foysal-os";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const userId = url.searchParams.get("userId") ?? "";
  const workspace = url.searchParams.get("workspace") ?? "foysal-it-agency";

  const result = await getWorkspaceSecureSnapshot(userId, workspace);
  return Response.json(result, { status: result.status });
}
