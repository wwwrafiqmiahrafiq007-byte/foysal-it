import { resetPassword } from "@/lib/auth-protocol";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { token?: string; password?: string };
  const result = await resetPassword(body.token ?? "", body.password ?? "");
  return Response.json(result, { status: result.status });
}

export async function GET(request: Request) {
  const token = new URL(request.url).searchParams.get("token") ?? "";
  return Response.json({
    ok: true,
    message: "Submit a POST request with this token and a new password to complete reset.",
    tokenReceived: Boolean(token),
    plaintextPasswordStored: false,
  });
}
