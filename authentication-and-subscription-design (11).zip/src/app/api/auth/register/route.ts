import { registerAccount } from "@/lib/auth-protocol";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const result = await registerAccount(body);
  return Response.json(result, { status: result.status });
}
