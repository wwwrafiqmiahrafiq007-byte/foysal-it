import { getFoysalOsSnapshot } from "@/lib/foysal-os";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getFoysalOsSnapshot();
  return Response.json({
    ok: true,
    workflows: snapshot.workflowTemplates,
    humanInTheLoop: snapshot.humanApprovalPolicies,
    aiWorkOsExample: "Create a complete digital marketing system for my business and prepare a client-ready report.",
    realDataStates: ["NO DATA", "NOT CONNECTED", "AUTHORIZATION REQUIRED", "UNSUPPORTED"],
    realDataPrinciple: "Never fabricate users, revenue, sales, leads, analytics, rankings, backlinks, conversions, commissions, AI usage, participants, voice activity, translation status, ad performance, health, or reports.",
  });
}
