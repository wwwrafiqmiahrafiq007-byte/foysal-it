import { getFullAppTestMatrix } from "@/lib/launch-readiness";

export const dynamic = "force-dynamic";

export async function GET() {
  const result = await getFullAppTestMatrix();
  return Response.json({ ok: true, ...result });
}
