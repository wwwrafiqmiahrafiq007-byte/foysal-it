import { getSubscriptionSalesReadiness } from "@/lib/launch-readiness";

export const dynamic = "force-dynamic";

export async function GET() {
  const result = await getSubscriptionSalesReadiness();
  return Response.json({ ok: true, ...result });
}
