import { getAppDistributionStatus } from "@/lib/strategy-audit";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({
    ok: true,
    distribution: getAppDistributionStatus(),
    principle: "The current product is a responsive installable PWA. Native Windows/macOS/iOS/Android apps can wrap the same API platform later without rebuilding the backend.",
  });
}
