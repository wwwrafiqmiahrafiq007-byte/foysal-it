import { getDeepHealthSnapshot } from "@/lib/platform-observability";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getDeepHealthSnapshot();
  return Response.json({ ok: true, ...snapshot });
}
