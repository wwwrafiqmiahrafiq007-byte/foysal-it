import { getFinalQaReport } from "@/lib/final-qa";

export const dynamic = "force-dynamic";

export async function GET() {
  const report = await getFinalQaReport();
  return Response.json({ ok: true, ...report });
}
