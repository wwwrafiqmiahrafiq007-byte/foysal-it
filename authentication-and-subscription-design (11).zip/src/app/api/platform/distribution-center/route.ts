import { getDistributionOverview } from "@/lib/distribution-center";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({ ok: true, ...getDistributionOverview() });
}
