import { getFoysalOsSnapshot } from "@/lib/foysal-os";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getFoysalOsSnapshot();
  return Response.json({
    ok: true,
    positioning: "FOYSAL IT OS — ONE PLATFORM. ONE WORKSPACE. ONE AI. ONE CONNECTED WORKFLOW.",
    engineeringPrinciple: "Independent → Permission-aware → API-ready → Scalable → Testable → Replaceable modules.",
    finalMasterFlow: ["DISCOVER", "PLAN", "CREATE", "MANAGE", "CONNECT", "AUTOMATE", "TRACK", "ANALYZE", "REPORT", "REVIEW", "OPTIMIZE", "GROW"],
    sections: snapshot.finalStructureSections,
  });
}
