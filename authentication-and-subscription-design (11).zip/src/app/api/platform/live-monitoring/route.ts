import { getLiveMonitoringSnapshot } from "@/lib/platform-observability";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getLiveMonitoringSnapshot();
  return Response.json({ ok: true, ...snapshot });
}
