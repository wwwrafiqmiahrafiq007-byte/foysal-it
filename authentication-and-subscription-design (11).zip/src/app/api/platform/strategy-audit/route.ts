import { getProfessionalStrategyAudit } from "@/lib/strategy-audit";

export const dynamic = "force-dynamic";

export async function GET() {
  const audit = await getProfessionalStrategyAudit();
  return Response.json({ ok: true, ...audit });
}
