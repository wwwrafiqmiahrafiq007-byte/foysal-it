import { getSanitizedPlatformOverview } from "@/lib/foysal-os";

export const dynamic = "force-dynamic";

export async function GET() {
  const overview = await getSanitizedPlatformOverview();
  return Response.json({ ok: true, ...overview, generatedAt: new Date().toISOString() });
}
