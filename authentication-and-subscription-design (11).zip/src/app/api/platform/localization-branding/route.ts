import { getFoysalOsSnapshot } from "@/lib/foysal-os";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getFoysalOsSnapshot();
  return Response.json({
    ok: true,
    globalization: snapshot.globalization,
    whiteLabel: snapshot.whiteLabel,
    agencyWhiteLabelFeatures: ["Logo", "Brand", "Domain", "Client Portal", "Report Branding", "Email Branding", "Theme"],
  });
}
