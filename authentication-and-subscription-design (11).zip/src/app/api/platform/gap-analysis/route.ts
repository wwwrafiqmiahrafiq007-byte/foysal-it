import { getGapAnalysis } from "@/lib/platform-observability";

export const dynamic = "force-dynamic";

export async function GET() {
  const analysis = await getGapAnalysis();
  return Response.json({ ok: true, ...analysis });
}
