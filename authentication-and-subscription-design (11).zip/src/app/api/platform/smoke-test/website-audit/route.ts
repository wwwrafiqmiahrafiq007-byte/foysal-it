import { runSafeWebsiteSmokeTest } from "@/lib/launch-readiness";

export const dynamic = "force-dynamic";

export async function GET() {
  const result = await runSafeWebsiteSmokeTest();
  return Response.json(result, { status: result.status });
}
