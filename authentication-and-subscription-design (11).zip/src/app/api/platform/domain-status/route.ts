import { getProductionUrls } from "@/lib/strategy-audit";

export const dynamic = "force-dynamic";

export async function GET() {
  const domain = getProductionUrls();
  return Response.json({
    ok: true,
    ...domain,
    requiredEnvironment: ["APP_URL", "PUBLIC_URL", "API_URL", "OAUTH_CALLBACK_URL", "WEBHOOK_URL"],
    productionChecklist: ["Point DNS to deployment", "Enable HTTPS/SSL", "Set secure cookies", "Update OAuth callbacks", "Update webhook URLs", "Verify canonical URLs", "Test email links and password reset links"],
  });
}
