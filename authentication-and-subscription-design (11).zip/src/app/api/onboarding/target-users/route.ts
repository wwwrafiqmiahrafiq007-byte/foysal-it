import { getFoysalOsSnapshot } from "@/lib/foysal-os";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getFoysalOsSnapshot();
  return Response.json({
    ok: true,
    onboardingFlow: ["Welcome", "Profile", "Role", "Industry", "Workspace", "Language", "Timezone", "Preferences", "Recommended Tools", "Integrations"],
    targetUsers: snapshot.targetSegments,
    selectedPreference: snapshot.onboardingPreference,
  });
}
