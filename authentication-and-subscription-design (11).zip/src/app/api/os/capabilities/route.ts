import { getFoysalOsSnapshot } from "@/lib/foysal-os";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getFoysalOsSnapshot();
  return Response.json({
    ok: true,
    architecture: "One configurable workspace-scoped OS capability engine, not separate disconnected applications.",
    workspace: snapshot.workspace.slug,
    capabilities: snapshot.osCapabilities,
    affiliatePrograms: snapshot.affiliatePrograms,
    cpaCampaigns: snapshot.cpaCampaigns,
    trackingMatrixEvents: snapshot.trackingMatrixEvents,
    externalConnectionPolicy: "Only show actual configured integrations. If unavailable, use recommendation/assistance mode or authorization_required status.",
  });
}
