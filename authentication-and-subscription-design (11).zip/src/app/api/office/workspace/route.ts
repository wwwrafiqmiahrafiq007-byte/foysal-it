import { getFoysalOsSnapshot } from "@/lib/foysal-os";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getFoysalOsSnapshot();
  return Response.json({
    ok: true,
    officeAssets: snapshot.officeAssets,
    calendarEvents: snapshot.calendarEvents,
    remoteMeetings: snapshot.remoteMeetings,
    supportedFormats: ["DOCX", "XLSX", "PPTX", "PDF", "CSV"],
    compatibilityPolicy: "Prioritizes common Office 2016-era document, spreadsheet, presentation, PDF and CSV workflows; does not claim every proprietary Microsoft Office feature unless implemented and tested.",
    globalVoiceTranslationPolicy: "Never show unsupported language or voice capabilities as active.",
  });
}
