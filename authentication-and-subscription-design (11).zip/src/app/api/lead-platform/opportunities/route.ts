import { db } from "@/db";
import { leadOpportunities } from "@/db/schema";
import { seedLeadPlatform, updateLeadScore } from "@/lib/lead-intelligence";
import { and, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { workspace } = await seedLeadPlatform();
  const leadId = new URL(request.url).searchParams.get("leadId");
  const rows = await db
    .select()
    .from(leadOpportunities)
    .where(leadId ? and(eq(leadOpportunities.workspaceId, workspace.id), eq(leadOpportunities.leadId, leadId)) : eq(leadOpportunities.workspaceId, workspace.id))
    .orderBy(desc(leadOpportunities.confidenceLevel), desc(leadOpportunities.createdAt));
  return Response.json({ ok: true, opportunities: rows });
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { leadId?: string };
  if (!body.leadId) return Response.json({ ok: false, error: "leadId is required after a website audit." }, { status: 400 });
  const lead = await updateLeadScore(body.leadId);
  return Response.json({ ok: Boolean(lead), lead, message: lead ? "Lead score refreshed from stored audit opportunities." : "Lead not found." }, { status: lead ? 200 : 404 });
}
