import { createLead, listLeads } from "@/lib/lead-intelligence";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const result = await listLeads({
    page: Number(url.searchParams.get("page") ?? 1),
    pageSize: Number(url.searchParams.get("pageSize") ?? 20),
    search: url.searchParams.get("search") ?? undefined,
    status: url.searchParams.get("status") ?? undefined,
    category: url.searchParams.get("category") ?? undefined,
  });
  return Response.json(result);
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const result = await createLead(body);
  return Response.json(result, { status: result.status });
}
