import { importLeads, parseCsvText, parseSpreadsheet, parseUnstructuredText, previewImport, seedLeadPlatform } from "@/lib/lead-intelligence";
import { db } from "@/db";
import { leadFiles } from "@/db/schema";

export const dynamic = "force-dynamic";

function googleSheetCsvUrl(sheetUrl: string) {
  const id = sheetUrl.match(/\/spreadsheets\/d\/([^/]+)/)?.[1];
  const gid = sheetUrl.match(/[?#&]gid=(\d+)/)?.[1] ?? "0";
  if (!id) return null;
  return `https://docs.google.com/spreadsheets/d/${id}/gviz/tq?tqx=out:csv&gid=${gid}`;
}

export async function POST(request: Request) {
  const contentType = request.headers.get("content-type") ?? "";
  const { workspace, owner } = await seedLeadPlatform();
  let rows = [] as ReturnType<typeof parseCsvText>;
  let fileRecord = null;
  let mode = "preview";

  if (contentType.includes("multipart/form-data")) {
    const form = await request.formData();
    const file = form.get("file");
    mode = String(form.get("mode") ?? "preview");
    if (!(file instanceof File)) {
      return Response.json({ ok: false, error: "File is required." }, { status: 400 });
    }
    const buffer = Buffer.from(await file.arrayBuffer());
    const name = file.name.toLowerCase();
    if (name.endsWith(".csv") || name.endsWith(".txt") || name.endsWith(".md")) rows = parseCsvText(buffer.toString("utf8"));
    else if (name.endsWith(".xlsx")) rows = await parseSpreadsheet(buffer, file.name);
    else if (name.endsWith(".xls")) {
      await db.insert(leadFiles).values({ workspaceId: workspace.id, fileName: file.name, fileType: file.type || "xls", fileSize: file.size, uploadedByUserId: owner.id, processingStatus: "Uploaded", aiAnalysisStatus: "Integration Required", errors: ["Legacy .xls parsing is disabled because the previously available parser has unresolved security vulnerabilities. Convert to .xlsx or CSV."] });
      return Response.json({ ok: false, status: "Integration Required", message: "Legacy .xls requires a secure conversion service. Convert the file to .xlsx or CSV and upload again." }, { status: 424 });
    } else {
      await db.insert(leadFiles).values({ workspaceId: workspace.id, fileName: file.name, fileType: file.type || "unknown", fileSize: file.size, uploadedByUserId: owner.id, processingStatus: "Uploaded", aiAnalysisStatus: "Integration Required", errors: ["This file type requires a connected extraction/OCR/AI provider before import."] });
      return Response.json({ ok: false, status: "Integration Required", message: "PDF, DOCX, PPTX, images and videos require a configured extraction/OCR/AI provider. No fake extraction was performed." }, { status: 424 });
    }
    const [record] = await db.insert(leadFiles).values({ workspaceId: workspace.id, fileName: file.name, fileType: file.type || name.split(".").pop() || "unknown", fileSize: file.size, uploadedByUserId: owner.id, processingStatus: "Completed", aiAnalysisStatus: "Completed", extractedInformation: { rows: rows.length } }).returning();
    fileRecord = record;
  } else {
    const body = (await request.json().catch(() => ({}))) as { mode?: string; sourceType?: string; content?: string; googleSheetUrl?: string; rows?: unknown[] };
    mode = body.mode ?? "preview";
    if (body.sourceType === "google_sheets") {
      const csvUrl = googleSheetCsvUrl(body.googleSheetUrl ?? "");
      if (!csvUrl) return Response.json({ ok: false, error: "Valid Google Sheet URL is required." }, { status: 400 });
      const response = await fetch(csvUrl, { signal: AbortSignal.timeout(12000) }).catch((error) => error as Error);
      if (response instanceof Error || !response.ok) {
        return Response.json({ ok: false, status: "Integration Required", message: "Google Sheet could not be read as public CSV. Connect Google account for private sheets or publish/export the sheet.", provider: "Google Sheets" }, { status: 424 });
      }
      rows = parseCsvText(await response.text());
    } else if (body.sourceType === "text") {
      rows = parseUnstructuredText(body.content ?? "");
    } else if (body.sourceType === "manual" && Array.isArray(body.rows)) {
      rows = body.rows as ReturnType<typeof parseCsvText>;
    } else {
      rows = parseCsvText(body.content ?? "");
    }
  }

  if (!rows.length) return Response.json({ ok: false, error: "No importable lead rows detected." }, { status: 400 });
  const preview = await previewImport(rows);
  if (mode === "import") {
    const result = await importLeads(rows);
    return Response.json({ ...result, file: fileRecord, preview: preview.preview.slice(0, 10) }, { status: result.status });
  }
  return Response.json({ ok: true, mode: "preview", file: fileRecord, ...preview });
}
