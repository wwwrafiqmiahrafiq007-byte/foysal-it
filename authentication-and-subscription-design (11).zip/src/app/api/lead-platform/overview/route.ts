import { getLeadPlatformSnapshot } from "@/lib/lead-intelligence";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getLeadPlatformSnapshot();
  return Response.json({ ok: true, ...snapshot });
}
