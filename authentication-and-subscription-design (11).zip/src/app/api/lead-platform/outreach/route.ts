import { approveOutreach, generateOutreach, sendOutreach } from "@/lib/lead-intelligence";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { action?: string; leadId?: string; messageId?: string; channel?: "email" | "whatsapp" };
  if (body.action === "approve" && body.messageId) {
    const result = await approveOutreach(body.messageId);
    return Response.json(result, { status: result.status });
  }
  if (body.action === "send" && body.messageId) {
    const result = await sendOutreach(body.messageId);
    return Response.json(result, { status: result.status });
  }
  if (!body.leadId) return Response.json({ ok: false, error: "leadId is required." }, { status: 400 });
  const result = await generateOutreach(body.leadId, body.channel ?? "email");
  return Response.json(result, { status: result.status });
}
