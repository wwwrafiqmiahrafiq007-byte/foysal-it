import { listLeads, seedLeadPlatform } from "@/lib/lead-intelligence";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  await seedLeadPlatform();
  const body = (await request.json().catch(() => ({}))) as { command?: string; confirm?: boolean };
  const command = body.command?.toLowerCase() ?? "";

  if (command.includes("hot") || command.includes("priority")) {
    const result = await listLeads({ category: "hot", pageSize: 50 });
    return Response.json({ ...result, type: "lead_search", explanation: "Showing hot/priority leads from actual workspace database records." });
  }
  if (command.includes("local seo")) {
    const result = await listLeads({ search: "local", pageSize: 50 });
    return Response.json({ ...result, type: "lead_search", explanation: "Use Local SEO score/opportunities after audits. No rankings are fabricated." });
  }
  if (command.includes("meta pixel") || command.includes("tracking")) {
    return Response.json({ ok: true, type: "integration_required", answer: "Tracking and Meta Pixel checks require configured integrations or website audit findings. If disconnected, status remains AUTHORIZATION REQUIRED / NOT CONNECTED." });
  }
  if (command.includes("generate outreach") || command.includes("top 50") || command.includes("create a campaign")) {
    return Response.json({ ok: false, type: "confirmation_required", preview: "This command can generate drafts, but external sending requires lead selection, review, approval, and a connected provider.", flow: ["SHOW PREVIEW", "ASK CONFIRMATION", "EXECUTE"] }, { status: 409 });
  }
  if (command.includes("performing best")) {
    return Response.json({ ok: true, type: "no_data", answer: "NO DATA: campaign performance requires sent campaigns and provider tracking. No performance was fabricated." });
  }
  return Response.json({ ok: true, type: "help", examples: ["Show all hot SEO leads.", "Find businesses that need Local SEO.", "Which leads have no detected Meta Pixel?", "Generate outreach for my top 50 leads.", "Show overdue follow-ups.", "Why is this lead high priority?"], policy: "External actions require preview and confirmation." });
}
