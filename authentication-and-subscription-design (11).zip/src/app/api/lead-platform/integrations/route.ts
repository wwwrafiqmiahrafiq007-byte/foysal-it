import { db } from "@/db";
import { leadPlatformIntegrations } from "@/db/schema";
import { seedLeadPlatform } from "@/lib/lead-intelligence";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const { workspace } = await seedLeadPlatform();
  const integrations = await db.select().from(leadPlatformIntegrations).where(eq(leadPlatformIntegrations.workspaceId, workspace.id)).orderBy(asc(leadPlatformIntegrations.category), asc(leadPlatformIntegrations.displayName));
  return Response.json({ ok: true, integrations, statuses: ["Connected", "Disconnected", "Connection Error", "Reconnect", "Test Connection"], secretsExposed: false });
}

export async function POST(request: Request) {
  const { workspace } = await seedLeadPlatform();
  const body = (await request.json().catch(() => ({}))) as { providerKey?: string; action?: string };
  if (!body.providerKey) return Response.json({ ok: false, error: "providerKey is required." }, { status: 400 });
  const [integration] = await db.select().from(leadPlatformIntegrations).where(eq(leadPlatformIntegrations.providerKey, body.providerKey));
  if (!integration || integration.workspaceId !== workspace.id) return Response.json({ ok: false, error: "Integration not found." }, { status: 404 });
  if (body.action === "test") {
    const canTest = integration.providerKey === "email_provider" ? Boolean(process.env.SMTP_HOST || process.env.RESEND_API_KEY) : integration.providerKey === "whatsapp_business" ? Boolean(process.env.WHATSAPP_ACCESS_TOKEN) : false;
    await db.update(leadPlatformIntegrations).set({ lastTestStatus: canTest ? "Credentials Present - Adapter Not Tested" : "Integration Required", status: canTest ? "Connection Error" : "Disconnected", updatedAt: new Date() }).where(eq(leadPlatformIntegrations.id, integration.id));
    return Response.json({ ok: canTest, status: canTest ? "Connection Error" : "Integration Required", message: canTest ? "Credentials are present but no send/read adapter has been tested in this sandbox." : integration.setupInstructions, secretsExposed: false }, { status: canTest ? 409 : 424 });
  }
  return Response.json({ ok: true, action: body.action ?? "setup", integration, setupInstructions: integration.setupInstructions, secretsExposed: false });
}
