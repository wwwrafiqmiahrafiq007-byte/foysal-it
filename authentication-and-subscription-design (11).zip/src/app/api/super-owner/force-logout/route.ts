import { forceLogoutUserSessions } from "@/lib/foysal-os";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { userId?: string };
  if (!body.userId) {
    return Response.json({ ok: false, error: "userId is required." }, { status: 400 });
  }

  await forceLogoutUserSessions(body.userId);
  return Response.json({ ok: true, message: "Active sessions force-logged out.", secretsDisplayed: false });
}
