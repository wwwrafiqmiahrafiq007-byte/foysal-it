import { getSuperOwnerUser360 } from "@/lib/foysal-os";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const userId = new URL(request.url).searchParams.get("userId") ?? undefined;
  const result = await getSuperOwnerUser360(userId);
  return Response.json({ ok: Boolean(result.user), ...result }, { status: result.user ? 200 : 404 });
}
