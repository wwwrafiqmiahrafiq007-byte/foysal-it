import { createAIEmployee, getAIWorkforceSnapshot } from "@/lib/ai-workforce";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getAIWorkforceSnapshot();
  return Response.json({ ok: true, employees: snapshot.employees, departmentCounts: snapshot.departmentCounts, statusCounts: snapshot.statusCounts });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const result = await createAIEmployee(body);
  return Response.json(result, { status: result.status });
}
