import { assignAIWorkforceTask, getAIWorkforceSnapshot } from "@/lib/ai-workforce";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getAIWorkforceSnapshot();
  return Response.json({ ok: true, tasks: snapshot.tasks, activities: snapshot.activities });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const result = await assignAIWorkforceTask(body);
  return Response.json(result, { status: result.status });
}
