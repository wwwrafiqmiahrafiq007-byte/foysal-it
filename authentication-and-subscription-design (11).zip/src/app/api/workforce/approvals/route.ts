import { getAIWorkforceSnapshot, updateApprovalItem } from "@/lib/ai-workforce";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getAIWorkforceSnapshot();
  return Response.json({ ok: true, approvals: snapshot.approvals });
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as { id?: string; action?: "Approve" | "Reject" | "Retry" | "Edit" };
  if (!body.id || !body.action) return Response.json({ ok: false, error: "id and action are required." }, { status: 400 });
  const result = await updateApprovalItem(body.id, body.action);
  return Response.json(result, { status: result.status });
}
