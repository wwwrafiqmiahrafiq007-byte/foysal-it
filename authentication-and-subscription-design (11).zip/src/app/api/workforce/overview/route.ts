import { getAIWorkforceSnapshot } from "@/lib/ai-workforce";

export const dynamic = "force-dynamic";

export async function GET() {
  const snapshot = await getAIWorkforceSnapshot();
  return Response.json({ ok: true, ...snapshot });
}
