import Image from "next/image";
import Link from "next/link";
import { getLeadPlatformSnapshot } from "@/lib/lead-intelligence";
import { LeadIntelligenceClient } from "./LeadIntelligenceClient";

export const dynamic = "force-dynamic";

export default async function LeadIntelligencePage() {
  const snapshot = await getLeadPlatformSnapshot();

  return (
    <main className="min-h-screen px-5 py-5 md:px-8">
      <div className="mx-auto max-w-7xl space-y-5">
        <nav className="glass-panel flex flex-col justify-between gap-4 rounded-[2rem] p-5 md:flex-row md:items-center">
          <Link href="/" className="flex items-center gap-3">
            <Image src="/foysal-it-mark.svg" alt="FOYSAL IT" width={48} height={48} className="rounded-2xl" />
            <div>
              <p className="font-black tracking-[0.18em]">FOYSAL IT</p>
              <p className="text-sm text-white/50">AI Lead Intelligence · Digital Audit · Sales OS</p>
            </div>
          </Link>
          <div className="flex flex-wrap gap-2">
            <Link href="/jarvis" className="rounded-full border border-yellow-200/25 bg-yellow-200/10 px-4 py-2 text-sm font-bold text-yellow-100">Jarvis Core</Link>
            <Link href="/dashboard" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">Unified OS</Link>
            <a href="/api/lead-platform/overview" className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">API</a>
            <a href={snapshot.company.website} className="rounded-full bg-white px-4 py-2 text-sm font-black text-[#250022]">Company Site</a>
          </div>
        </nav>
        <LeadIntelligenceClient initial={snapshot} />
      </div>
    </main>
  );
}
