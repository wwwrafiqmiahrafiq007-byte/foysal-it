"use client";

import { useMemo, useState, useTransition } from "react";

type Lead = {
  id: string;
  company: string;
  contact: string | null;
  email: string | null;
  phone: string | null;
  whatsapp: string | null;
  website: string | null;
  industry: string | null;
  location: string | null;
  leadScore: number;
  websiteScore: number;
  seoScore: number;
  localSeoScore: number;
  socialScore: number;
  recommendedServices: string[];
  status: string;
  aiSummary: string | null;
  aiScoreReasoning: string[];
};

type Snapshot = {
  company: { name: string; whatsapp: string; email: string; website: string; servicesUrl: string; appUrl: string; services: string[] };
  leads: Lead[];
  stages: Array<{ id: string; name: string; sortOrder: number }>;
  integrations: Array<{ id: string; providerKey: string; displayName: string; category: string; status: string; lastTestStatus: string; setupInstructions: string }>;
  jobs: Array<{ id: string; jobType: string; status: string; progress: number; resultSummary: string | null; errorMessage: string | null }>;
  campaigns: Array<{ id: string; name: string; status: string; dailyLimit: number; complianceNotes: string[] }>;
  messages: Array<{ id: string; leadId: string; channel: string; subject: string | null; body: string; status: string; providerStatus: string }>;
  counts: { leads: number; priorityLeads: number; audits: number; opportunities: number };
  realDataPolicy: string[];
};

const defaultCsv = `Company,Contact,Email,Phone,Website,Industry,Location,Notes\nExample Business,Owner,owner@example.com,+8801700000000,https://example.com,Local Service,Dhaka,Needs digital marketing review`;

export function LeadIntelligenceClient({ initial }: { initial: Snapshot }) {
  const [snapshot, setSnapshot] = useState(initial);
  const [selectedLeadId, setSelectedLeadId] = useState(initial.leads[0]?.id ?? "");
  const [manual, setManual] = useState({ company: "", contact: "", email: "", phone: "", website: "", industry: "", location: "" });
  const [csv, setCsv] = useState(defaultCsv);
  const [sheetUrl, setSheetUrl] = useState("https://docs.google.com/spreadsheets/d/1I14GPL_LLCvSUyHT8aU2xDSJAXLxIDuUFweSDUrqWLA/edit?gid=389305097#gid=389305097");
  const [file, setFile] = useState<File | null>(null);
  const [command, setCommand] = useState("Show all hot SEO leads.");
  const [result, setResult] = useState<string>("Ready. Add/import leads, run audits, generate outreach, then approve before sending.");
  const [isPending, startTransition] = useTransition();

  const selectedLead = useMemo(() => snapshot.leads.find((lead) => lead.id === selectedLeadId) ?? snapshot.leads[0], [snapshot.leads, selectedLeadId]);

  async function refresh() {
    const response = await fetch("/api/lead-platform/overview");
    const data = await response.json();
    setSnapshot(data);
    if (!selectedLeadId && data.leads?.[0]?.id) setSelectedLeadId(data.leads[0].id);
  }

  function run(label: string, action: () => Promise<unknown>) {
    setResult(`${label}: Loading...`);
    startTransition(async () => {
      try {
        const data = await action();
        setResult(JSON.stringify(data, null, 2));
        await refresh();
      } catch (error) {
        setResult(`${label}: Error — ${error instanceof Error ? error.message : "Unknown error"}`);
      }
    });
  }

  async function postJson(url: string, body: unknown) {
    const response = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    const data = await response.json();
    if (!response.ok && !data.message && !data.error) throw new Error(`Request failed: ${response.status}`);
    return data;
  }

  async function uploadSelectedFile(mode: "preview" | "import") {
    if (!file) return { ok: false, error: "Choose a CSV, XLSX, XLS, TXT or Markdown file first." };
    const form = new FormData();
    form.append("file", file);
    form.append("mode", mode);
    const response = await fetch("/api/lead-platform/import", { method: "POST", body: form });
    return response.json();
  }

  return (
    <div className="space-y-5">
      <section className="glass-panel rounded-[2rem] p-6 md:p-8">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.34em] text-yellow-200/75">FOYSAL IT · Lead Intelligence SaaS</p>
            <h1 className="mt-3 text-4xl font-black tracking-[-0.05em] md:text-6xl">Turn every lead into an opportunity.</h1>
            <p className="mt-4 max-w-4xl text-white/65">AI-powered lead intelligence, digital audit, marketing opportunity, outreach automation and sales management — connected to real database operations and honest integration states.</p>
          </div>
          <div className="grid min-w-72 grid-cols-2 gap-3">
            <div className="rounded-2xl border border-white/10 bg-black/20 p-4"><p className="text-sm text-white/45">Leads</p><p className="text-3xl font-black">{snapshot.counts.leads}</p></div>
            <div className="rounded-2xl border border-white/10 bg-black/20 p-4"><p className="text-sm text-white/45">Audits</p><p className="text-3xl font-black">{snapshot.counts.audits}</p></div>
            <div className="rounded-2xl border border-white/10 bg-black/20 p-4"><p className="text-sm text-white/45">Opportunities</p><p className="text-3xl font-black">{snapshot.counts.opportunities}</p></div>
            <div className="rounded-2xl border border-white/10 bg-black/20 p-4"><p className="text-sm text-white/45">Priority</p><p className="text-3xl font-black">{snapshot.counts.priorityLeads}</p></div>
          </div>
        </div>
      </section>

      <section className="grid gap-5 xl:grid-cols-[1.05fr_0.95fr]">
        <div className="glass-panel rounded-[2rem] p-6">
          <div className="flex items-center justify-between gap-3"><h2 className="text-2xl font-black">+ ADD DATA</h2><span className="rounded-full border border-emerald-300/25 bg-emerald-400/10 px-3 py-1 text-xs font-bold text-emerald-100">Functional CSV/XLSX/Text/Public Sheets</span></div>
          <p className="mt-2 text-sm text-white/55">Upload → Identify → Extract → Structure → Validate → Duplicate Check → Review → Import.</p>
          <div className="mt-5 grid gap-4 lg:grid-cols-2">
            <div className="space-y-3">
              <input aria-label="Company" value={manual.company} onChange={(e) => setManual({ ...manual, company: e.target.value })} className="w-full rounded-2xl border border-white/10 bg-black/25 px-4 py-3 outline-none focus:border-yellow-200" placeholder="Company *" />
              <input aria-label="Contact" value={manual.contact} onChange={(e) => setManual({ ...manual, contact: e.target.value })} className="w-full rounded-2xl border border-white/10 bg-black/25 px-4 py-3 outline-none focus:border-yellow-200" placeholder="Contact" />
              <input aria-label="Email" value={manual.email} onChange={(e) => setManual({ ...manual, email: e.target.value })} className="w-full rounded-2xl border border-white/10 bg-black/25 px-4 py-3 outline-none focus:border-yellow-200" placeholder="Email" />
              <input aria-label="Website" value={manual.website} onChange={(e) => setManual({ ...manual, website: e.target.value })} className="w-full rounded-2xl border border-white/10 bg-black/25 px-4 py-3 outline-none focus:border-yellow-200" placeholder="Website" />
              <button disabled={isPending} onClick={() => run("Create lead", () => postJson("/api/lead-platform/leads", manual))} className="w-full rounded-2xl bg-gradient-to-r from-fuchsia-500 to-yellow-300 px-4 py-3 font-black text-[#250022] disabled:opacity-50">Create Lead</button>
            </div>
            <div className="space-y-3">
              <textarea aria-label="CSV or text import" value={csv} onChange={(e) => setCsv(e.target.value)} className="min-h-36 w-full rounded-2xl border border-white/10 bg-black/25 px-4 py-3 text-sm outline-none focus:border-yellow-200" />
              <div className="grid gap-3 md:grid-cols-2">
                <button disabled={isPending} onClick={() => run("Preview CSV", () => postJson("/api/lead-platform/import", { sourceType: "csv", content: csv, mode: "preview" }))} className="rounded-2xl border border-white/15 px-4 py-3 font-bold text-white/80 disabled:opacity-50">Preview CSV</button>
                <button disabled={isPending} onClick={() => run("Import CSV", () => postJson("/api/lead-platform/import", { sourceType: "csv", content: csv, mode: "import" }))} className="rounded-2xl border border-yellow-200/25 bg-yellow-200/10 px-4 py-3 font-bold text-yellow-100 disabled:opacity-50">Import CSV</button>
              </div>
              <input aria-label="Google Sheet URL" value={sheetUrl} onChange={(e) => setSheetUrl(e.target.value)} className="w-full rounded-2xl border border-white/10 bg-black/25 px-4 py-3 text-sm outline-none focus:border-yellow-200" placeholder="Google Sheet URL" />
              <button disabled={isPending} onClick={() => run("Import Google Sheet", () => postJson("/api/lead-platform/import", { sourceType: "google_sheets", googleSheetUrl: sheetUrl, mode: "import" }))} className="w-full rounded-2xl border border-white/15 px-4 py-3 font-bold text-white/80 disabled:opacity-50">Import Public Google Sheet / Require Integration</button>
              <input aria-label="Upload lead file" type="file" accept=".csv,.xlsx,.xls,.txt,.md" onChange={(e) => setFile(e.target.files?.[0] ?? null)} className="w-full rounded-2xl border border-white/10 bg-black/25 px-4 py-3 text-sm text-white/70 file:mr-3 file:rounded-full file:border-0 file:bg-white file:px-3 file:py-1 file:text-xs file:font-bold file:text-[#250022]" />
              <div className="grid gap-3 md:grid-cols-2">
                <button disabled={isPending || !file} onClick={() => run("Preview file", () => uploadSelectedFile("preview"))} className="rounded-2xl border border-white/15 px-4 py-3 font-bold text-white/80 disabled:opacity-50">Preview File</button>
                <button disabled={isPending || !file} onClick={() => run("Import file", () => uploadSelectedFile("import"))} className="rounded-2xl border border-yellow-200/25 bg-yellow-200/10 px-4 py-3 font-bold text-yellow-100 disabled:opacity-50">Import File</button>
              </div>
            </div>
          </div>
        </div>

        <div className="glass-panel rounded-[2rem] p-6">
          <h2 className="text-2xl font-black">Operation Result</h2>
          <p className="mt-2 text-sm text-white/55">Loading, progress, success, warning, error, retry and integration-required states are returned by APIs.</p>
          <pre className="mt-5 max-h-[30rem] overflow-auto rounded-2xl border border-white/10 bg-black/35 p-4 text-xs leading-5 text-white/72">{result}</pre>
        </div>
      </section>

      <section className="grid gap-5 xl:grid-cols-[1.15fr_0.85fr]">
        <div className="glass-panel rounded-[2rem] p-6">
          <div className="flex flex-col justify-between gap-3 md:flex-row md:items-center"><h2 className="text-2xl font-black">Lead Database</h2><button onClick={refresh} className="rounded-full border border-white/15 px-4 py-2 text-sm font-bold text-white/75">Refresh</button></div>
          <div className="mt-5 overflow-x-auto">
            <div className="min-w-[760px] space-y-3">
              {snapshot.leads.length ? snapshot.leads.map((lead) => (
                <button key={lead.id} onClick={() => setSelectedLeadId(lead.id)} className={`grid w-full gap-3 rounded-2xl border p-4 text-left md:grid-cols-[1.3fr_0.9fr_0.7fr_0.8fr] ${selectedLead?.id === lead.id ? "border-yellow-200/45 bg-yellow-200/10" : "border-white/10 bg-white/[0.045]"}`}>
                  <div><p className="font-black">{lead.company}</p><p className="text-sm text-white/50">{lead.contact || "No contact"} · {lead.email || lead.phone || "No contact channel"}</p></div>
                  <div><p className="text-sm text-white/40">Website</p><p className="truncate text-sm text-white/75">{lead.website || "NO DATA"}</p></div>
                  <div><p className="text-sm text-white/40">Score</p><p className="text-2xl font-black text-yellow-100">{lead.leadScore}</p></div>
                  <div><p className="text-sm text-white/40">Status</p><p className="font-bold text-white/80">{lead.status}</p></div>
                </button>
              )) : <div className="rounded-2xl border border-white/10 bg-black/20 p-6 text-white/60">No leads yet. Add a lead, import CSV/XLSX, paste text, or import an accessible Google Sheet.</div>}
            </div>
          </div>
        </div>

        <div className="glass-panel rounded-[2rem] p-6">
          <h2 className="text-2xl font-black">360° Lead Profile</h2>
          {selectedLead ? (
            <div className="mt-5 space-y-4">
              <div className="rounded-2xl border border-white/10 bg-black/20 p-4"><p className="text-sm text-white/40">Who is this business?</p><p className="mt-1 font-black">{selectedLead.company}</p><p className="mt-2 text-sm text-white/55">{selectedLead.aiSummary || "Run an audit to generate a clearer lead intelligence summary."}</p></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-white/10 bg-white/[0.045] p-4"><p className="text-sm text-white/40">Website</p><p className="text-2xl font-black">{selectedLead.websiteScore}</p></div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.045] p-4"><p className="text-sm text-white/40">SEO</p><p className="text-2xl font-black">{selectedLead.seoScore}</p></div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.045] p-4"><p className="text-sm text-white/40">Local SEO</p><p className="text-2xl font-black">{selectedLead.localSeoScore}</p></div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.045] p-4"><p className="text-sm text-white/40">Social</p><p className="text-2xl font-black">{selectedLead.socialScore}</p></div>
              </div>
              <div className="flex flex-wrap gap-2">{selectedLead.recommendedServices.length ? selectedLead.recommendedServices.map((service) => <span key={service} className="rounded-full border border-yellow-200/25 bg-yellow-200/10 px-3 py-1 text-xs font-bold text-yellow-100">{service}</span>) : <span className="text-sm text-white/45">No service recommendation yet.</span>}</div>
              <div className="grid gap-3 md:grid-cols-2">
                <button disabled={isPending || !selectedLead.website} onClick={() => run("Website audit", () => postJson("/api/lead-platform/audits/website", { leadId: selectedLead.id }))} className="rounded-2xl bg-white px-4 py-3 font-black text-[#250022] disabled:opacity-50">Run Website Audit</button>
                <button disabled={isPending} onClick={() => run("Generate outreach", () => postJson("/api/lead-platform/outreach", { leadId: selectedLead.id, channel: "email" }))} className="rounded-2xl border border-yellow-200/25 bg-yellow-200/10 px-4 py-3 font-bold text-yellow-100 disabled:opacity-50">Generate Outreach</button>
              </div>
              <div className="rounded-2xl border border-fuchsia-300/20 bg-fuchsia-400/10 p-4"><p className="font-bold">AI side panel</p><p className="mt-1 text-sm text-white/65">“WHAT SHOULD I DO WITH THIS LEAD?” Run audit → review evidence → approve personalized outreach → schedule compliant follow-up → update pipeline.</p></div>
            </div>
          ) : <p className="mt-5 text-white/55">Select or create a lead to open the 360° profile.</p>}
        </div>
      </section>

      <section className="grid gap-5 lg:grid-cols-3">
        <div className="glass-panel rounded-[2rem] p-6"><h2 className="text-2xl font-black">Sales Pipeline</h2><div className="mt-5 flex flex-wrap gap-2">{snapshot.stages.map((stage) => <span key={stage.id} className="rounded-full border border-white/15 bg-white/[0.055] px-3 py-1 text-xs font-bold text-white/75">{stage.name}</span>)}</div></div>
        <div className="glass-panel rounded-[2rem] p-6"><h2 className="text-2xl font-black">AI Processing Center</h2><div className="mt-5 space-y-3">{snapshot.jobs.length ? snapshot.jobs.map((job) => <div key={job.id} className="rounded-2xl border border-white/10 bg-black/20 p-3"><p className="font-bold">{job.jobType}</p><p className="text-sm text-white/50">{job.status} · {job.progress}% {job.errorMessage ? `· ${job.errorMessage}` : ""}</p></div>) : <p className="text-white/50">No AI/background jobs yet.</p>}</div></div>
        <div className="glass-panel rounded-[2rem] p-6"><h2 className="text-2xl font-black">Integrations</h2><div className="mt-5 space-y-3">{snapshot.integrations.slice(0, 6).map((integration) => <div key={integration.id} className="rounded-2xl border border-white/10 bg-black/20 p-3"><p className="font-bold">{integration.displayName}</p><p className="text-sm text-yellow-100">{integration.status} · {integration.lastTestStatus}</p></div>)}</div></div>
      </section>

      <section className="grid gap-5 lg:grid-cols-[0.85fr_1.15fr]">
        <div className="glass-panel rounded-[2rem] p-6">
          <h2 className="text-2xl font-black">AI Command Center</h2>
          <textarea aria-label="AI command" value={command} onChange={(e) => setCommand(e.target.value)} className="mt-4 min-h-28 w-full rounded-2xl border border-white/10 bg-black/25 px-4 py-3 outline-none focus:border-yellow-200" />
          <button disabled={isPending} onClick={() => run("AI command", () => postJson("/api/lead-platform/command", { command }))} className="mt-3 w-full rounded-2xl bg-gradient-to-r from-fuchsia-500 to-yellow-300 px-4 py-3 font-black text-[#250022] disabled:opacity-50">Run Command</button>
        </div>
        <div className="glass-panel rounded-[2rem] p-6">
          <h2 className="text-2xl font-black">Responsible Automation</h2>
          <div className="mt-5 grid gap-3 md:grid-cols-2">
            {snapshot.campaigns.map((campaign) => <div key={campaign.id} className="rounded-2xl border border-white/10 bg-black/20 p-4"><p className="font-bold">{campaign.name}</p><p className="mt-1 text-sm text-white/50">{campaign.status} · Daily limit {campaign.dailyLimit}</p><p className="mt-2 text-xs text-yellow-100">{campaign.complianceNotes.join(" · ")}</p></div>)}
            {snapshot.messages.map((message) => <div key={message.id} className="rounded-2xl border border-white/10 bg-white/[0.045] p-4"><p className="font-bold">{message.subject || message.channel}</p><p className="mt-1 text-sm text-white/50">{message.status} · {message.providerStatus}</p><div className="mt-3 flex gap-2"><button onClick={() => run("Approve", () => postJson("/api/lead-platform/outreach", { action: "approve", messageId: message.id }))} className="rounded-full border border-emerald-300/25 px-3 py-1 text-xs font-bold text-emerald-100">Approve</button><button onClick={() => run("Send", () => postJson("/api/lead-platform/outreach", { action: "send", messageId: message.id }))} className="rounded-full border border-yellow-200/25 px-3 py-1 text-xs font-bold text-yellow-100">Send</button></div></div>)}
          </div>
        </div>
      </section>
    </div>
  );
}
